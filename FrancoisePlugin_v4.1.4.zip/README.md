### How to Install a Figma Plugin from an Archive (Local Installation)

1. **Extract the archive** (ZIP file) containing the plugin to any folder on your computer.
2. Open the **Figma Desktop App** (local plugins cannot be installed via the web browser version).
3. Open any design file.
4. Right-click anywhere on the canvas (or open the main Figma menu in the top left corner).
5. Navigate to **Plugins** -> **Development** -> **Import plugin from manifest...**
6. In the file browser, locate the folder you extracted in step 1, select the `manifest.json` file, and click **Open**.

**Done!** You can now find and run your plugin anytime via *Plugins -> Development*.

----------------------------------------------------------------------------------------

### Инструкция по установке плагина из архива (Локальная установка)

1. **Распакуйте архив** с плагином в любую удобную папку на вашем компьютере.
2. Откройте **десктопное приложение Figma** (установка локальных плагинов не поддерживается в веб-версии браузера).
3. Откройте любой файл дизайна.
4. Нажмите правой кнопкой мыши в любом месте на холсте (или откройте главное меню Figma в левом верхнем углу).
5. В контекстном меню выберите **Plugins** (Плагины) -> **Development** (Разработка) -> **Import plugin from manifest...** (Импортировать плагин из манифеста).
6. В открывшемся окне найдите распакованную папку, выберите файл `manifest.json` и нажмите **Открыть**.

**Готово!** Теперь вы можете запускать этот плагин через меню: *Plugins -> Development*.