"use strict";
figma.showUI(__html__, { width: 320, height: 320, themeColors: true });
// 1. Получаем ID текущего пользователя Фигмы (hardware bind)
const figmaUserId = figma.currentUser ? figma.currentUser.id : 'anonymous_user';
// 2. Читаем сохраненные данные при запуске
Promise.all([
    figma.clientStorage.getAsync('francoise_user_email'),
    figma.clientStorage.getAsync('francoise_api_key')
]).then(([savedEmail, savedApiKey]) => {
    figma.ui.postMessage({
        type: 'init-env',
        email: savedEmail || '',
        apiKey: savedApiKey || '',
        figmaUserId: figmaUserId
    });
}); // <--- ДОБАВИТЬ ВОТ ЭТУ СТРОЧКУ
// ==========================================
// --- SAFE CASTING HELPERS ДЛЯ FIGMA API ---
// ==========================================
function hasAction(err, actionName) {
    var _a;
    const meta = (_a = err.details) === null || _a === void 0 ? void 0 : _a.metadata;
    if (!meta)
        return false;
    const commands = meta.actions || (meta.action ? [meta] : []);
    return commands.some((c) => c.action === actionName);
}
function safeGrow(val) {
    const num = parseFloat(val);
    if (isNaN(num) || num <= 0)
        return 0;
    return 1;
}
function safeNum(val, min = 0, fallback = 0) {
    if (val === undefined || val === null)
        return fallback;
    const parsed = parseFloat(String(val));
    if (isNaN(parsed))
        return fallback;
    return Math.max(min, parsed);
}
function safeEnum(val, validValues, fallback) {
    if (!val || typeof val !== 'string')
        return fallback;
    const upperVal = val.toUpperCase();
    return validValues.includes(upperVal) ? upperVal : fallback;
}
function rgbToHex(r, g, b) {
    const toHex = (n) => Math.max(0, Math.min(255, Math.round(n * 255))).toString(16).padStart(2, '0');
    return `#${toHex(r)}${toHex(g)}${toHex(b)}`.toUpperCase();
}
function resolveTokenName(tokenId) {
    try {
        const variable = figma.variables.getVariableById(tokenId);
        return variable ? variable.name : null;
    }
    catch (e) {
        return null;
    }
}
// ==========================================
// --- 1. КЛИЕНТСКИЙ СБОРЩИК (ВАЛИДАЦИЯ) ---
// ==========================================
let totalNodesScanned = 0;
async function serializeNode(node, isRoot = false) {
    // Выводим жирный лог ТОЛЬКО для корневого элемента, который уходит на сервер
    if (isRoot) {
        console.log(`\n======================================================`);
        console.log(`3️⃣ [Francoise Serializer] 🧱 НАЧАЛО СЕРИАЛИЗАЦИИ КОРНЯ`);
        console.log(`   ├─ Имя: ${node.name}`);
        console.log(`   ├─ Тип: ${node.type}`);
        console.log(`   └─ ID:  ${node.id}`);
        console.log(`======================================================\n`);
    }
    totalNodesScanned++;
    if (totalNodesScanned % 200 === 0) {
        console.log(`[Francoise Gatherer] ⏳ В процессе... Просканировано узлов: ${totalNodesScanned}`);
    }
    await new Promise(resolve => setTimeout(resolve, 2));
    if (node.name === "FRANCOISE_HIGHLIGHT")
        return null;
    if ('visible' in node && !node.visible)
        return null;
    if ('componentProperties' in node) {
        try {
            const _check = node.componentProperties;
        }
        catch (e) {
            console.warn(`[Francoise Gatherer] ⏭️ Пропущен битый узел "${node.name}" (${node.id}): ошибка Фигмы.`);
            return null;
        }
    }
    let hasImage = false;
    if ('fills' in node && Array.isArray(node.fills))
        hasImage = node.fills.some(f => f.type === 'IMAGE');
    if (!hasImage && 'strokes' in node && Array.isArray(node.strokes))
        hasImage = node.strokes.some(s => s.type === 'IMAGE');
    let imageBase64 = null;
    if (hasImage) {
        try {
            const nodeImageBytes = await node.exportAsync({ format: 'JPG', constraint: { type: 'SCALE', value: 1 } });
            imageBase64 = figma.base64Encode(nodeImageBytes);
        }
        catch (e) {
            console.warn(`Failed to export image for ${node.name}`);
        }
    }
    let masterKey = null;
    let compId = null;
    let compSetId = null;
    let compSetKey = null;
    if (node.type === 'INSTANCE') {
        try {
            const mainComp = await node.getMainComponentAsync();
            if (mainComp) {
                masterKey = mainComp.key;
                compId = mainComp.id;
                if (mainComp.parent && mainComp.parent.type === 'COMPONENT_SET') {
                    compSetId = mainComp.parent.id;
                    compSetKey = mainComp.parent.key;
                }
            }
        }
        catch (e) { }
    }
    else if (node.type === 'COMPONENT') {
        compId = node.id;
        if (node.parent && node.parent.type === 'COMPONENT_SET') {
            compSetId = node.parent.id;
            compSetKey = node.parent.key;
        }
    }
    const bbox = 'absoluteBoundingBox' in node ? node.absoluteBoundingBox : null;
    const renderBounds = 'absoluteRenderBounds' in node ? node.absoluteRenderBounds : null;
    const enrichedBoundVariables = {};
    if ('boundVariables' in node && node.boundVariables) {
        for (const [key, alias] of Object.entries(node.boundVariables)) {
            if (alias && alias.type === 'VARIABLE_ALIAS') {
                enrichedBoundVariables[key] = { id: alias.id, name: resolveTokenName(alias.id) };
            }
        }
    }
    const data = {
        id: node.id,
        name: node.name,
        type: node.type,
        visible: true,
        clipsContent: 'clipsContent' in node ? node.clipsContent : false,
        opacity: 'opacity' in node ? node.opacity : 1.0,
        blendMode: 'blendMode' in node ? node.blendMode : 'NORMAL',
        master_component_key: masterKey,
        mainComponentKey: masterKey,
        mainComponentId: compId,
        mainComponentSetId: compSetId,
        mainComponentSetKey: compSetKey,
        image_base64: imageBase64,
        style: {},
        styles: {},
        x: 'x' in node ? node.x : (bbox ? bbox.x : 0),
        y: 'y' in node ? node.y : (bbox ? bbox.y : 0),
        rotation: 'rotation' in node ? node.rotation : 0,
        strokeWeight: 'strokeWeight' in node ? (node.strokeWeight === figma.mixed ? 1 : node.strokeWeight) : 0,
        componentPropertyReferences: 'componentPropertyReferences' in node ? node.componentPropertyReferences : {},
        isMask: 'isMask' in node ? node.isMask : false,
        absoluteBoundingBox: bbox ? { x: bbox.x, y: bbox.y, width: bbox.width, height: bbox.height } : null,
        absoluteRenderBounds: renderBounds ? { x: renderBounds.x, y: renderBounds.y, width: renderBounds.width, height: renderBounds.height } : null,
        layoutMode: 'layoutMode' in node && node.layoutMode !== 'NONE' ? node.layoutMode : 'NONE',
        paddingTop: 'paddingTop' in node ? node.paddingTop : 0,
        paddingBottom: 'paddingBottom' in node ? node.paddingBottom : 0,
        paddingLeft: 'paddingLeft' in node ? node.paddingLeft : 0,
        paddingRight: 'paddingRight' in node ? node.paddingRight : 0,
        itemSpacing: 'itemSpacing' in node ? node.itemSpacing : 0,
        width: 'width' in node ? node.width : (bbox ? bbox.width : null),
        height: 'height' in node ? node.height : (bbox ? bbox.height : null),
        layoutSizingHorizontal: 'layoutSizingHorizontal' in node ? node.layoutSizingHorizontal : null,
        layoutSizingVertical: 'layoutSizingVertical' in node ? node.layoutSizingVertical : null,
        primaryAxisSizingMode: 'primaryAxisSizingMode' in node ? node.primaryAxisSizingMode : null,
        counterAxisSizingMode: 'counterAxisSizingMode' in node ? node.counterAxisSizingMode : null,
        layoutAlign: 'layoutAlign' in node ? node.layoutAlign : null,
        layoutGrow: 'layoutGrow' in node ? node.layoutGrow : null,
        layoutPositioning: 'layoutPositioning' in node ? node.layoutPositioning : 'AUTO',
        primaryAxisAlignItems: 'primaryAxisAlignItems' in node ? node.primaryAxisAlignItems : null,
        counterAxisAlignItems: 'counterAxisAlignItems' in node ? node.counterAxisAlignItems : null,
        layoutWrap: 'layoutWrap' in node ? node.layoutWrap : null,
        minWidth: 'minWidth' in node ? node.minWidth : null,
        maxWidth: 'maxWidth' in node ? node.maxWidth : null,
        minHeight: 'minHeight' in node ? node.minHeight : null,
        maxHeight: 'maxHeight' in node ? node.maxHeight : null,
        constraints: 'constraints' in node ? node.constraints : null,
        cornerRadius: 'cornerRadius' in node ? (node.cornerRadius === figma.mixed ? 0 : node.cornerRadius) : 0,
        rectangleCornerRadii: 'topLeftRadius' in node ? [node.topLeftRadius, node.topRightRadius, node.bottomRightRadius, node.bottomLeftRadius] : null,
        pluginData: {
            francoise_approved_name: node.getPluginData('francoise_approved_name'),
            original_component_id: 'getSharedPluginData' in node ? node.getSharedPluginData('francoise', 'original_component_id') : '',
            original_component_key: 'getSharedPluginData' in node ? node.getSharedPluginData('francoise', 'original_component_key') : '',
            original_component_set_key: 'getSharedPluginData' in node ? node.getSharedPluginData('francoise', 'original_component_set_key') : ''
        },
        boundVariables: enrichedBoundVariables,
        componentProperties: 'componentProperties' in node ? node.componentProperties : null
    };
    if ('fills' in node) {
        if (node.fills === figma.mixed) {
            data.fills = [{ type: 'IMAGE', visible: true }];
        }
        else if (Array.isArray(node.fills)) {
            data.fills = node.fills.map(p => {
                const paint = { type: p.type, visible: p.visible };
                if (p.opacity !== undefined)
                    paint.opacity = p.opacity;
                if (p.type === 'SOLID') {
                    paint.color = p.color;
                    paint.color_object = p.color;
                    paint.hex = rgbToHex(p.color.r, p.color.g, p.color.b);
                    if (p.boundVariables && p.boundVariables.color) {
                        paint.boundVariableId = p.boundVariables.color.id;
                        paint.token_id = p.boundVariables.color.id;
                        paint.token_name = resolveTokenName(p.boundVariables.color.id);
                    }
                    // 🚀 ДОБАВИТЬ ЭТОТ БЛОК: Пробрасываем сырые переменные для Python-трансформатора
                    if (p.boundVariables) {
                        paint.boundVariables = p.boundVariables;
                    }
                } // 🚀 НОВОЕ: Обрабатываем градиенты и их точки (Gradient Stops)
                else if (p.type.startsWith('GRADIENT_')) {
                    paint.gradientStops = p.gradientStops.map((stop) => {
                        const stopData = {
                            position: stop.position,
                            color: stop.color,
                            color_object: stop.color,
                            hex: rgbToHex(stop.color.r, stop.color.g, stop.color.b)
                        };
                        if (stop.boundVariables) {
                            stopData.boundVariables = stop.boundVariables;
                            if (stop.boundVariables.color) {
                                stopData.boundVariableId = stop.boundVariables.color.id;
                                stopData.token_id = stop.boundVariables.color.id;
                                stopData.token_name = resolveTokenName(stop.boundVariables.color.id);
                            }
                        }
                        return stopData;
                    });
                    if (p.boundVariables)
                        paint.boundVariables = p.boundVariables;
                }
                return paint;
            });
        }
    }
    if ('strokes' in node) {
        if (node.strokes === figma.mixed) {
            data.strokes = [{ type: 'SOLID', visible: true, color: { r: 0, g: 0, b: 0 }, opacity: 1 }];
        }
        else if (Array.isArray(node.strokes)) {
            data.strokes = node.strokes.map(p => {
                const paint = { type: p.type, visible: p.visible };
                if (p.opacity !== undefined)
                    paint.opacity = p.opacity;
                if (p.type === 'SOLID') {
                    paint.color = p.color;
                    paint.color_object = p.color;
                    paint.hex = rgbToHex(p.color.r, p.color.g, p.color.b);
                    if (p.boundVariables && p.boundVariables.color) {
                        paint.boundVariableId = p.boundVariables.color.id;
                        paint.token_id = p.boundVariables.color.id;
                        paint.token_name = resolveTokenName(p.boundVariables.color.id);
                    }
                    if (p.boundVariables)
                        paint.boundVariables = p.boundVariables;
                }
                // 🚀 ВЫНЕСЕНО ИЗ-ПОД SOLID
                else if (p.type.startsWith('GRADIENT_')) {
                    paint.gradientStops = p.gradientStops.map((stop) => {
                        const stopData = {
                            position: stop.position,
                            color: stop.color,
                            color_object: stop.color,
                            hex: rgbToHex(stop.color.r, stop.color.g, stop.color.b)
                        };
                        if (stop.boundVariables) {
                            stopData.boundVariables = stop.boundVariables;
                            if (stop.boundVariables.color) {
                                stopData.boundVariableId = stop.boundVariables.color.id;
                                stopData.token_id = stop.boundVariables.color.id;
                                stopData.token_name = resolveTokenName(stop.boundVariables.color.id);
                            }
                        }
                        return stopData;
                    });
                    if (p.boundVariables)
                        paint.boundVariables = p.boundVariables;
                }
                return paint;
            });
        }
    }
    if ('effects' in node) {
        data.effects = node.effects.map((e) => ({
            type: e.type,
            visible: e.visible !== false,
            radius: e.radius,
            offset: e.offset ? { x: e.offset.x, y: e.offset.y } : { x: 0, y: 0 },
            // 🚀 ДОБАВИТЬ ПЕРЕДАЧУ ПЕРЕМЕННЫХ
            boundVariables: e.boundVariables || null
        }));
    }
    if ('textStyleId' in node && typeof node.textStyleId === 'string' && node.textStyleId)
        data.styles.text = node.textStyleId;
    if ('fillStyleId' in node && typeof node.fillStyleId === 'string' && node.fillStyleId)
        data.styles.fill = node.fillStyleId;
    if ('strokeStyleId' in node && typeof node.strokeStyleId === 'string' && node.strokeStyleId)
        data.styles.stroke = node.strokeStyleId;
    if (node.type === 'TEXT') {
        data.characters = node.characters || (node.hasMissingFont ? "[Missing Font]" : "");
        data.textAutoResize = node.textAutoResize;
        const len = data.characters.length > 0 ? 1 : 0;
        const fName = node.fontName === figma.mixed ? (len ? node.getRangeFontName(0, 1) : null) : node.fontName;
        if (fName && fName !== figma.mixed) {
            data.style.fontFamily = fName.family;
            data.style.fontWeight = fName.style;
        }
        const fSize = node.fontSize === figma.mixed ? (len ? node.getRangeFontSize(0, 1) : null) : node.fontSize;
        if (fSize !== null && fSize !== undefined && fSize !== figma.mixed)
            data.style.fontSize = fSize;
        const lHeight = node.lineHeight === figma.mixed ? (len ? node.getRangeLineHeight(0, 1) : null) : node.lineHeight;
        if (lHeight && lHeight !== figma.mixed && lHeight.unit === 'PIXELS')
            data.style.lineHeightPx = lHeight.value;
        const lSpacing = node.letterSpacing === figma.mixed ? (len ? node.getRangeLetterSpacing(0, 1) : null) : node.letterSpacing;
        if (lSpacing && lSpacing !== figma.mixed && lSpacing.unit === 'PIXELS')
            data.style.letterSpacing = lSpacing.value;
        data.style.textAlignHorizontal = node.textAlignHorizontal;
        data.style.textAlignVertical = node.textAlignVertical;
    }
    const vectorTypes = ['VECTOR', 'BOOLEAN_OPERATION', 'STAR', 'ELLIPSE', 'REGULAR_POLYGON', 'LINE'];
    if (vectorTypes.includes(node.type)) {
        if ('fillGeometry' in node && Array.isArray(node.fillGeometry))
            data.fillGeometry = node.fillGeometry.map((g) => ({ path: g.path }));
        if ('strokeGeometry' in node && Array.isArray(node.strokeGeometry))
            data.strokeGeometry = node.strokeGeometry.map((g) => ({ path: g.path }));
    }
    if ('children' in node) {
        data.children = [];
        for (const child of node.children) {
            const serializedChild = await serializeNode(child);
            if (serializedChild)
                data.children.push(serializedChild);
        }
    }
    return data;
}
// ==========================================
// --- 2. АДМИНСКИЙ СБОРЩИК (ПАРСИНГ DS) ----
// ==========================================
function updateUIProgress(message, percent) {
    figma.ui.postMessage({ type: 'progress', message: message, percent: `${Math.min(100, Math.max(0, percent))}%` });
}
function getPageName(node) {
    let parent = node.parent;
    while (parent && parent.type !== 'PAGE')
        parent = parent.parent;
    return parent && parent.type === 'PAGE' ? parent.name : "";
}
function getContextText(node) {
    let parent = node.parent;
    while (parent && parent.type !== 'FRAME' && parent.type !== 'SECTION' && parent.type !== 'PAGE')
        parent = parent.parent;
    if (!parent || parent.type === 'PAGE')
        return "";
    const textNodes = [];
    if ('findAll' in parent) {
        const found = parent.findAll((n) => {
            if (n.type !== 'TEXT' || !n.visible)
                return false;
            let current = n.parent;
            while (current && current !== parent) {
                if (current.type === 'COMPONENT' || current.type === 'INSTANCE' || current.type === 'COMPONENT_SET')
                    return false;
                current = current.parent;
            }
            return true;
        });
        textNodes.push(...found);
    }
    return textNodes.map(t => t.characters).join('\n\n').substring(0, 2000);
}
// Отдельная сериализация для Design System (без патчей UI)
async function serializeDSNode(node) {
    const res = { id: node.id, type: node.type, name: node.name, visible: node.visible };
    if ('key' in node && typeof node.key === 'string')
        res.key = node.key;
    if ('absoluteBoundingBox' in node && node.absoluteBoundingBox) {
        res.absoluteBoundingBox = { x: node.absoluteBoundingBox.x, y: node.absoluteBoundingBox.y, width: node.absoluteBoundingBox.width, height: node.absoluteBoundingBox.height };
    }
    if ('width' in node)
        res.width = node.width;
    if ('height' in node)
        res.height = node.height;
    if ('rotation' in node)
        res.rotation = node.rotation;
    if ('layoutMode' in node)
        res.layoutMode = node.layoutMode;
    if ('layoutWrap' in node)
        res.layoutWrap = node.layoutWrap;
    if ('primaryAxisAlignItems' in node)
        res.primaryAxisAlignItems = node.primaryAxisAlignItems;
    if ('counterAxisAlignItems' in node)
        res.counterAxisAlignItems = node.counterAxisAlignItems;
    if ('primaryAxisSizingMode' in node)
        res.primaryAxisSizingMode = node.primaryAxisSizingMode;
    if ('counterAxisSizingMode' in node)
        res.counterAxisSizingMode = node.counterAxisSizingMode;
    if ('layoutSizingHorizontal' in node)
        res.layoutSizingHorizontal = node.layoutSizingHorizontal;
    if ('layoutSizingVertical' in node)
        res.layoutSizingVertical = node.layoutSizingVertical;
    if ('layoutAlign' in node)
        res.layoutAlign = node.layoutAlign;
    if ('layoutGrow' in node)
        res.layoutGrow = node.layoutGrow;
    if ('minWidth' in node && node.minWidth !== null)
        res.minWidth = node.minWidth;
    if ('maxWidth' in node && node.maxWidth !== null)
        res.maxWidth = node.maxWidth;
    if ('minHeight' in node && node.minHeight !== null)
        res.minHeight = node.minHeight;
    if ('maxHeight' in node && node.maxHeight !== null)
        res.maxHeight = node.maxHeight;
    if ('layoutPositioning' in node)
        res.layoutPositioning = node.layoutPositioning;
    if ('constraints' in node)
        res.constraints = node.constraints;
    if ('clipsContent' in node)
        res.clipsContent = node.clipsContent;
    if ('isMask' in node)
        res.isMask = node.isMask;
    if ('paddingLeft' in node) {
        res.paddingLeft = node.paddingLeft;
        res.paddingRight = node.paddingRight;
        res.paddingTop = node.paddingTop;
        res.paddingBottom = node.paddingBottom;
        res.itemSpacing = node.itemSpacing;
    }
    if ('cornerRadius' in node)
        res.cornerRadius = node.cornerRadius === figma.mixed ? 0 : node.cornerRadius;
    if ('strokeWeight' in node)
        res.strokeWeight = node.strokeWeight === figma.mixed ? 1 : node.strokeWeight;
    if ('opacity' in node)
        res.opacity = node.opacity;
    if ('rectangleCornerRadii' in node)
        res.rectangleCornerRadii = node.rectangleCornerRadii;
    if ('fills' in node) {
        if (node.fills === figma.mixed)
            res.fills = [{ type: 'IMAGE', visible: true }];
        else if (Array.isArray(node.fills)) {
            res.fills = node.fills.map(p => {
                const paint = { type: p.type, visible: p.visible };
                if (p.opacity !== undefined)
                    paint.opacity = p.opacity;
                if (p.type === 'SOLID') {
                    paint.color = p.color;
                    paint.color_object = p.color;
                }
                else if (p.type.startsWith('GRADIENT_')) {
                    // 🚀 Прокидываем точки градиента для расчета диполей на сервере
                    paint.gradientStops = p.gradientStops.map((stop) => ({
                        position: stop.position,
                        color: stop.color,
                        color_object: stop.color,
                        boundVariables: stop.boundVariables || null
                    }));
                }
                if (p.boundVariables)
                    paint.boundVariables = p.boundVariables;
                return paint;
            });
        }
    }
    if ('strokes' in node) {
        if (node.strokes === figma.mixed)
            res.strokes = [{ type: 'SOLID', visible: true, color: { r: 0, g: 0, b: 0 }, opacity: 1 }];
        else if (Array.isArray(node.strokes)) {
            res.strokes = node.strokes.map(p => {
                const paint = { type: p.type, visible: p.visible };
                if (p.opacity !== undefined)
                    paint.opacity = p.opacity;
                if (p.type === 'SOLID') {
                    paint.color = p.color;
                    paint.color_object = p.color;
                }
                else if (p.type.startsWith('GRADIENT_')) {
                    // 🚀 Аналогично для обводок
                    paint.gradientStops = p.gradientStops.map((stop) => ({
                        position: stop.position,
                        color: stop.color,
                        color_object: stop.color,
                        boundVariables: stop.boundVariables || null
                    }));
                }
                if (p.boundVariables)
                    paint.boundVariables = p.boundVariables;
                return paint;
            });
        }
    }
    if ('effects' in node && Array.isArray(node.effects))
        res.effects = node.effects.map(e => ({ type: e.type, visible: e.visible }));
    if (node.type === 'TEXT') {
        res.characters = node.characters;
        const len = node.characters.length > 0 ? 1 : 0;
        res.fontSize = node.fontSize === figma.mixed ? (len ? node.getRangeFontSize(0, 1) : 12) : node.fontSize;
        res.fontName = node.fontName === figma.mixed ? (len ? node.getRangeFontName(0, 1) : { family: "Inter", style: "Regular" }) : node.fontName;
        if ('fontWeight' in node)
            res.fontWeight = node.fontWeight === figma.mixed ? (len ? node.getRangeFontWeight(0, 1) : 400) : node.fontWeight;
        if ('lineHeight' in node)
            res.lineHeight = node.lineHeight === figma.mixed ? (len ? node.getRangeLineHeight(0, 1) : { unit: "AUTO" }) : node.lineHeight;
        if ('letterSpacing' in node)
            res.letterSpacing = node.letterSpacing === figma.mixed ? (len ? node.getRangeLetterSpacing(0, 1) : { value: 0, unit: "PIXELS" }) : node.letterSpacing;
        if ('textDecoration' in node)
            res.textDecoration = node.textDecoration === figma.mixed ? (len ? node.getRangeTextDecoration(0, 1) : "NONE") : node.textDecoration;
        if ('textAutoResize' in node)
            res.textAutoResize = node.textAutoResize;
        res.textAlignHorizontal = node.textAlignHorizontal;
        res.textAlignVertical = node.textAlignVertical;
        if ('textStyleId' in node && typeof node.textStyleId === 'string' && node.textStyleId !== '')
            res.textStyleId = node.textStyleId;
        res.style = { fontWeight: res.fontWeight, fontSize: res.fontSize, textDecoration: res.textDecoration || "NONE", textAlignHorizontal: res.textAlignHorizontal || "LEFT", textAlignVertical: res.textAlignVertical || "TOP" };
        res.styles = { text: res.textStyleId || "" };
    }
    try {
        if ('boundVariables' in node)
            res.boundVariables = node.boundVariables;
        if ('componentPropertyReferences' in node)
            res.componentPropertyReferences = node.componentPropertyReferences;
    }
    catch (e) { }
    if (node.type === 'INSTANCE') {
        const instanceNode = node;
        try {
            const master = await instanceNode.getMainComponentAsync();
            try {
                if ('componentProperties' in instanceNode)
                    res.componentProperties = instanceNode.componentProperties;
            }
            catch (e) { }
            if (master) {
                res.mainComponentId = master.id;
                res.mainComponentKey = master.key;
                res.mainComponentName = master.name;
                res.is_external = master.remote;
            }
            else {
                res.mainComponentId = null;
                res.mainComponentKey = null;
                res.mainComponentName = node.name;
                res.is_external = true;
            }
        }
        catch (e) {
            res.mainComponentId = null;
            res.mainComponentKey = null;
            res.mainComponentName = node.name;
            res.is_external = true;
        }
    }
    if ('children' in node && node.type !== 'BOOLEAN_OPERATION') {
        res.children = [];
        for (const child of node.children) {
            res.children.push(await serializeDSNode(child));
        }
    }
    return res;
}
async function processComponentsLocally(initialComps) {
    var _a;
    const queue = [...initialComps.filter(c => {
            var _a;
            if (c.type === 'COMPONENT' && ((_a = c.parent) === null || _a === void 0 ? void 0 : _a.type) === 'COMPONENT_SET')
                return false;
            return true;
        })];
    const processedKeys = new Set();
    const blueprintsMeta = [];
    const nodesToHydrate = new Set();
    let count = 0;
    while (queue.length > 0) {
        const c = queue.shift();
        if (c.key && processedKeys.has(c.key))
            continue;
        if (c.key)
            processedKeys.add(c.key);
        count++;
        let safeProps = {};
        try {
            let rawProps = null;
            if (c.type === 'COMPONENT_SET')
                rawProps = c.componentPropertyDefinitions;
            else if (c.type === 'COMPONENT')
                rawProps = ((_a = c.parent) === null || _a === void 0 ? void 0 : _a.type) === 'COMPONENT_SET' ? c.parent.componentPropertyDefinitions : c.componentPropertyDefinitions;
            if (rawProps)
                safeProps = JSON.parse(JSON.stringify(rawProps));
        }
        catch (e) { }
        try {
            for (const propName in safeProps) {
                const def = safeProps[propName];
                if (def.type === 'INSTANCE_SWAP' && Array.isArray(def.preferredValues)) {
                    const isIconProp = propName.toLowerCase().includes('icon') || propName.toLowerCase().includes('asset');
                    for (const pref of def.preferredValues) {
                        if (isIconProp) {
                            pref.resolved_name = "INSTANCE:ANY_ICON";
                            continue;
                        }
                        if (pref.key && !processedKeys.has(pref.key)) {
                            pref.resolved_name = "EXTERNAL_BLACKBOX";
                            processedKeys.add(pref.key);
                        }
                    }
                }
            }
            const childInstances = c.findAllWithCriteria({ types: ['INSTANCE'] });
            for (const inst of childInstances) {
                try {
                    const master = await inst.getMainComponentAsync();
                    if (master && master.remote && master.key) {
                        const nameLower = (inst.name || master.name || "").toLowerCase();
                        const isIconInstance = nameLower.includes('icon') || nameLower.includes('lucide') || nameLower.includes('phosphor') || nameLower.includes('tabler') || nameLower.includes('remix');
                        if (isIconInstance)
                            continue;
                        if (!processedKeys.has(master.key))
                            processedKeys.add(master.key);
                    }
                }
                catch (e) { }
            }
        }
        catch (e) { } // <--- ВЕРНУЛИ ПОТЕРЯННЫЙ ЗАКРЫВАЮЩИЙ БЛОК TRY
        if (c.type === 'COMPONENT_SET') {
            const variants = c.findAllWithCriteria({ types: ['COMPONENT'] });
            variants.forEach(v => nodesToHydrate.add(v));
            const defaultVar = c.defaultVariant || variants[0];
            if (defaultVar)
                nodesToHydrate.add(defaultVar);
        }
        else if (c.type === 'COMPONENT')
            nodesToHydrate.add(c);
        blueprintsMeta.push({
            node: c, id: c.id, key: c.key, type: c.type, name: c.name, is_external: c.remote, page_name: getPageName(c),
            description: c.description || "", componentPropertyDefinitions: safeProps, context_text: getContextText(c)
        });
        if (count % 5 === 0) {
            updateUIProgress(`Mapping components: ${count}...`, Math.min(20, count));
            await new Promise(r => setTimeout(r, 5));
        }
    }
    const hydratedDataMap = new Map();
    const hydrateArray = Array.from(nodesToHydrate);
    const CHUNK_SIZE = 50;
    const originalPage = figma.currentPage;
    const tempPage = figma.createPage();
    tempPage.name = "🔧 Françoise Parsing (Do Not Touch)";
    await figma.setCurrentPageAsync(tempPage); // <--- ИСПРАВЛЕНО
    for (let i = 0; i < hydrateArray.length; i += CHUNK_SIZE) {
        const chunk = hydrateArray.slice(i, i + CHUNK_SIZE);
        const instances = [];
        for (const comp of chunk) {
            try {
                const instance = comp.createInstance();
                tempPage.appendChild(instance);
                const originalMeta = { id: comp.id, type: 'COMPONENT', name: comp.name };
                if ('key' in comp && typeof comp.key === 'string')
                    originalMeta.key = comp.key;
                if (comp.parent && comp.parent.type === 'COMPONENT_SET') {
                    originalMeta.componentSetId = comp.parent.id;
                    if ('key' in comp.parent && typeof comp.parent.key === 'string')
                        originalMeta.componentSetKey = comp.parent.key;
                }
                instances.push({ instance, originalMeta });
            }
            catch (e) { }
        }
        await new Promise(r => setTimeout(r, 25));
        for (const item of instances) {
            const serialized = await serializeDSNode(item.instance);
            Object.assign(serialized, item.originalMeta);
            delete serialized.mainComponentId;
            delete serialized.mainComponentKey;
            delete serialized.mainComponentName;
            delete serialized.is_external;
            delete serialized.componentProperties;
            hydratedDataMap.set(item.originalMeta.id, serialized);
        }
        instances.forEach(item => { if (!item.instance.removed)
            item.instance.remove(); });
        updateUIProgress(`Extracting data: ${Math.min(i + CHUNK_SIZE, hydrateArray.length)} / ${hydrateArray.length}`, 20 + Math.round((i / hydrateArray.length) * 60));
    }
    await figma.setCurrentPageAsync(originalPage); // <--- ИСПРАВЛЕНО
    tempPage.remove();
    return blueprintsMeta.map(meta => {
        const c = meta.node;
        let raw_node = null;
        let variants = [];
        if (c.type === 'COMPONENT_SET') {
            const defaultVar = c.defaultVariant || c.children[0];
            if (defaultVar && hydratedDataMap.has(defaultVar.id)) {
                raw_node = JSON.parse(JSON.stringify(hydratedDataMap.get(defaultVar.id)));
                raw_node.id = c.id;
                raw_node.type = 'COMPONENT_SET';
                if ('key' in c)
                    raw_node.key = c.key;
            }
            const childVariants = c.findAllWithCriteria({ types: ['COMPONENT'] });
            variants = childVariants.filter((v) => hydratedDataMap.has(v.id)).map((v) => hydratedDataMap.get(v.id));
        }
        else {
            if (hydratedDataMap.has(c.id))
                raw_node = hydratedDataMap.get(c.id);
        }
        return {
            id: meta.id, key: meta.key, type: meta.type, name: meta.name, is_external: meta.is_external, page_name: meta.page_name,
            description: meta.description, componentPropertyDefinitions: meta.componentPropertyDefinitions, context_text: meta.context_text, raw_node: raw_node, variants: variants
        };
    });
}
function mapFontWeight(styleName) {
    const s = styleName.toLowerCase();
    if (s.includes('thin') || s.includes('hairline'))
        return 100;
    if (s.includes('extra light') || s.includes('extralight'))
        return 200;
    if (s.includes('light'))
        return 300;
    if (s.includes('medium'))
        return 500;
    if (s.includes('semi') && s.includes('bold'))
        return 600;
    if (s.includes('extra') && s.includes('bold'))
        return 800;
    if (s.includes('bold'))
        return 700;
    if (s.includes('black') || s.includes('heavy'))
        return 900;
    return 400;
}
function getLineHeightPx(lh, fontSize) {
    if (lh.unit === 'PIXELS')
        return lh.value;
    if (lh.unit === 'PERCENT')
        return (lh.value / 100) * fontSize;
    return null;
}
async function exportTokens(fileUrl, iconsUrl, colorsUrl, storybookUrl, steps) {
    // Подгружаем все страницы в память, чтобы избежать ошибки dynamic-page
    try {
        await figma.loadAllPagesAsync();
    }
    catch (e) {
        console.warn("[Françoise] Ошибка подгрузки страниц:", e);
    }
    const registry = { typography: [], colors: [], spacing: [], shadows: [], radii: [] };
    if (steps.includes('tokens')) {
        const processedIds = new Set();
        async function resolveVariableValue(val) {
            if (typeof val === 'object' && val !== null && 'type' in val && val.type === 'VARIABLE_ALIAS') {
                try {
                    const targetVar = await figma.variables.getVariableByIdAsync(val.id);
                    if (targetVar) {
                        await processVariable(targetVar);
                        const modes = Object.keys(targetVar.valuesByMode);
                        if (modes.length > 0)
                            return await resolveVariableValue(targetVar.valuesByMode[modes[0]]);
                    }
                }
                catch (e) { }
                return null;
            }
            return val;
        }
        async function processVariable(v) {
            var _a;
            if (processedIds.has(v.id))
                return;
            processedIds.add(v.id);
            const modes = Object.keys(v.valuesByMode);
            if (modes.length === 0)
                return;
            const rawVal = v.valuesByMode[modes[0]];
            const val = await resolveVariableValue(rawVal);
            if (v.resolvedType === 'COLOR' && val && val.r !== undefined) {
                const colorVal = val;
                const scopes = v.scopes || [];
                const nameLower = v.name.toLowerCase();
                let semanticTargets = ["all"];
                if (scopes.includes("TEXT_CONTENT") || nameLower.includes("text") || nameLower.includes("typography") || nameLower.includes("on-"))
                    semanticTargets = ["text"];
                else if (scopes.includes("FRAME_FILL") || scopes.includes("SHAPE_FILL") || nameLower.includes("bg") || nameLower.includes("background") || nameLower.includes("surface") || nameLower.includes("canvas") || nameLower.includes("bg-"))
                    semanticTargets = ["fill"];
                else if (scopes.includes("STROKE_COLOR") || nameLower.includes("border") || nameLower.includes("stroke") || nameLower.includes("divider") || nameLower.includes("line"))
                    semanticTargets = ["stroke"];
                else if (nameLower.includes("icon"))
                    semanticTargets = ["icon", "text", "fill"];
                registry.colors.push({
                    id: v.name, figma_id: v.id, key: v.key, name: v.name, type: "VARIABLE",
                    semantic_targets: semanticTargets, r: colorVal.r, g: colorVal.g, b: colorVal.b, a: (_a = colorVal.a) !== null && _a !== void 0 ? _a : 1.0
                });
            }
            else if (v.resolvedType === 'FLOAT' && typeof val === 'number') {
                const scopes = v.scopes || [];
                const nameLower = v.name.toLowerCase();
                const isRadius = scopes.includes('CORNER_RADIUS') || nameLower.includes('radius') || nameLower.includes('radii') || nameLower.includes('round') || nameLower.includes('corner');
                if (isRadius)
                    registry.radii.push({ id: v.name, figma_id: v.id, key: v.key, name: v.name, type: "VARIABLE", value: val });
                else
                    registry.spacing.push({ id: v.name, figma_id: v.id, key: v.key, name: v.name, type: "VARIABLE", value: val });
            }
        }
        function processStyle(s) {
            var _a;
            if (processedIds.has(s.id))
                return;
            processedIds.add(s.id);
            if (s.type === 'PAINT') {
                const paints = s.paints;
                const solid = paints.find(p => p.type === 'SOLID');
                if (solid) {
                    const nameLower = s.name.toLowerCase();
                    let semanticTargets = ["all"];
                    if (nameLower.includes("text") || nameLower.includes("typography") || nameLower.includes("on-"))
                        semanticTargets = ["text"];
                    else if (nameLower.includes("bg") || nameLower.includes("background") || nameLower.includes("surface") || nameLower.includes("canvas") || nameLower.includes("bg-"))
                        semanticTargets = ["fill"];
                    else if (nameLower.includes("border") || nameLower.includes("stroke") || nameLower.includes("divider") || nameLower.includes("line"))
                        semanticTargets = ["stroke"];
                    else if (nameLower.includes("icon"))
                        semanticTargets = ["icon", "text", "fill"];
                    registry.colors.push({
                        id: s.name, figma_id: s.id, key: s.key, name: s.name, type: "STYLE",
                        semantic_targets: semanticTargets, r: solid.color.r, g: solid.color.g, b: solid.color.b, a: (_a = solid.opacity) !== null && _a !== void 0 ? _a : 1.0
                    });
                }
            }
            else if (s.type === 'TEXT') {
                const ts = s;
                let langGroup = "Latin";
                const nameLower = ts.name.toLowerCase();
                const fontLower = ts.fontName.family.toLowerCase();
                if (nameLower.includes('cyrillic') || nameLower.includes('ru') || fontLower.includes('suisse'))
                    langGroup = "Cyrillic";
                else if (nameLower.includes('latin') || nameLower.includes('en') || fontLower.includes('agrandir'))
                    langGroup = "Latin";
                else if (nameLower.includes('hindi') || nameLower.includes('thai') || fontLower.includes('noto'))
                    langGroup = "Hindi";
                else if (nameLower.includes('arabic'))
                    langGroup = "Arabic";
                else if (nameLower.includes('hebrew'))
                    langGroup = "Hebrew";
                registry.typography.push({
                    id: ts.name, figma_id: ts.id, key: ts.key, name: ts.name, language_group: langGroup,
                    type: "STYLE", family: ts.fontName.family, size: ts.fontSize, weights: [mapFontWeight(ts.fontName.style)], line_height: getLineHeightPx(ts.lineHeight, ts.fontSize)
                });
            }
            else if (s.type === 'EFFECT') {
                const es = s;
                const shadows = es.effects.filter((e) => e.type === 'DROP_SHADOW' || e.type === 'INNER_SHADOW');
                if (shadows.length > 0) {
                    registry.shadows.push({
                        id: es.name, figma_id: es.id, key: es.key, name: es.name, type: "STYLE",
                        effects: shadows.map(sh => ({ type: sh.type, color: sh.color, offset: sh.offset, radius: sh.radius, spread: sh.spread || 0 }))
                    });
                }
            }
        }
        const localVariables = await figma.variables.getLocalVariablesAsync();
        for (const v of localVariables)
            await processVariable(v);
        const paintStyles = await figma.getLocalPaintStylesAsync();
        const textStyles = await figma.getLocalTextStylesAsync();
        const effectStyles = await figma.getLocalEffectStylesAsync();
        for (const s of [...paintStyles, ...textStyles, ...effectStyles])
            processStyle(s);
        const externalVarIds = new Set();
        const findVariableAliases = (obj) => {
            if (!obj)
                return;
            if (typeof obj === 'object') {
                if (obj.type === 'VARIABLE_ALIAS' && obj.id)
                    externalVarIds.add(obj.id);
                else
                    for (const key of Object.keys(obj))
                        findVariableAliases(obj[key]);
            }
        };
        const nodes = figma.root.findAll();
        const totalNodes = nodes.length;
        updateUIProgress(`Analyzing external connections...`, 10);
        for (let i = 0; i < totalNodes; i++) {
            const node = nodes[i];
            const anyNode = node;
            if (anyNode.fillStyleId && typeof anyNode.fillStyleId === 'string' && !processedIds.has(anyNode.fillStyleId)) {
                const s = await figma.getStyleByIdAsync(anyNode.fillStyleId);
                if (s)
                    processStyle(s);
            }
            if (anyNode.textStyleId && typeof anyNode.textStyleId === 'string' && !processedIds.has(anyNode.textStyleId)) {
                const s = await figma.getStyleByIdAsync(anyNode.textStyleId);
                if (s)
                    processStyle(s);
            }
            if ('boundVariables' in node && node.boundVariables)
                findVariableAliases(node.boundVariables);
            if ((i + 1) % 1000 === 0 || i === totalNodes - 1) {
                updateUIProgress(`Scanning layers: ${i + 1} of ${totalNodes}...`, 10 + Math.round(((i + 1) / totalNodes) * 20));
                await new Promise(r => setTimeout(r, 10));
            }
        }
        const totalVars = externalVarIds.size;
        let varsProcessed = 0;
        for (const varId of externalVarIds) {
            varsProcessed++;
            if (!processedIds.has(varId)) {
                try {
                    const extVar = await figma.variables.getVariableByIdAsync(varId);
                    if (extVar)
                        await processVariable(extVar);
                }
                catch (e) { }
            }
            if (varsProcessed % 10 === 0 || varsProcessed === totalVars) {
                updateUIProgress(`Resolving tokens: ${varsProcessed} of ${totalVars}...`, 30 + Math.round((varsProcessed / totalVars) * 10));
            }
        }
    }
    let finalComponentData = [];
    if (steps.includes('blueprints')) {
        const comps = figma.root.findAllWithCriteria({ types: ['COMPONENT', 'COMPONENT_SET'] });
        const validComps = comps.filter(c => {
            const pageName = getPageName(c).toLowerCase();
            if (pageName.includes('icon') || pageName.includes('asset') || pageName.includes('illustration'))
                return false;
            const nameLower = c.name.toLowerCase();
            if (nameLower.includes('icon/') || nameLower.includes('lucide/') || nameLower.includes('phosphor/') || nameLower.includes('tabler/') || nameLower.includes('remix/'))
                return false;
            return true;
        });
        finalComponentData = await processComponentsLocally(validComps);
    }
    const fileName = figma.root.name;
    updateUIProgress("Preparing final package...", 85);
    figma.ui.postMessage({
        type: 'export_payload',
        fileName, fileUrl, iconsUrl, colorsUrl, storybookUrl: "", steps,
        data: registry, componentData: finalComponentData
    });
}
// ==========================================
// --- 3. ГЛАВНЫЙ МАРШРУТИЗАТОР СООБЩЕНИЙ ---
// ==========================================
// 🚀 ДОБАВИТЬ ВОТ ЭТУ СТРОЧКУ ЗДЕСЬ:
let activeGatherSessionId = 0;
figma.ui.onmessage = async (msg) => {
    var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l;
    // --- АДМИНСКИЕ СООБЩЕНИЯ (DS EXTRACTOR) ---
    if (msg.type === 'extract_and_sync') {
        await exportTokens(msg.fileUrl, msg.iconsUrl, msg.colorsUrl, msg.storybookUrl, msg.steps);
        return;
    }
    if (msg.type === 'render_screenshots') {
        const screenshots = {};
        for (const id of msg.nodes) {
            try {
                let node = figma.getNodeById(id);
                if (!node)
                    continue;
                if (node.type === 'COMPONENT_SET' && node.children.length > 0) {
                    node = node.defaultVariant || node.children[0];
                }
                if (!node.visible || node.width === 0 || node.height === 0)
                    continue;
                if ('exportAsync' in node) {
                    const bytes = await node.exportAsync({ format: 'PNG', constraint: { type: 'SCALE', value: 2 } });
                    screenshots[id] = figma.base64Encode(bytes);
                }
            }
            catch (e) {
                console.error(`[Françoise] Failed to render node ${id}:`, e);
            }
        }
        figma.ui.postMessage({ type: 'screenshots_ready', screenshots: screenshots, jobId: msg.jobId });
        return;
    }
    // --- КЛИЕНТСКИЕ СООБЩЕНИЯ (UI VALIDATION) ---
    if (msg.type === 'save-email') {
        await figma.clientStorage.setAsync('francoise_user_email', msg.email);
        return;
    }
    if (msg.type === 'resize-window') {
        figma.ui.resize(320, msg.expanded ? 540 : 280);
        return;
    }
    if (msg.type === 'get-selection') {
        activeGatherSessionId = msg.sessionId;
        console.log(`\n======================================================`);
        console.log(`🚨 [Francoise Gatherer] 🚀 СТАРТ СЕССИИ: ${msg.sessionId}`);
        const selection = figma.currentPage.selection;
        console.log(`1️⃣ Сырое выделение (figma.currentPage.selection): ${selection.length} шт.`);
        if (selection.length === 0) {
            console.log(`   └─ ❌ Пустое выделение. Отмена.`);
            figma.notify("Сначала выделите объект на макете");
            return;
        }
        selection.forEach((n, idx) => console.log(`   ├─ [${idx}] "${n.name}" (type: ${n.type}, id: ${n.id})`));
        // Берем ровно то, что выделил юзер! Без самодеятельности.
        const nodesToProcess = Array.from(selection);
        figma.notify(`Сбор данных для ${nodesToProcess.length} объектов...`);
        for (let i = 0; i < nodesToProcess.length; i++) {
            if (activeGatherSessionId !== msg.sessionId) {
                console.log("🛑 Старая сессия отменена новым запросом.");
                return;
            }
            const node = nodesToProcess[i];
            totalNodesScanned = 0;
            try {
                let rootImageBase64 = null;
                if ('exportAsync' in node) {
                    const rootImageBytes = await node.exportAsync({ format: 'JPG', constraint: { type: 'SCALE', value: 2 } });
                    rootImageBase64 = figma.base64Encode(rootImageBytes);
                }
                const serialized = await serializeNode(node, true);
                if (serialized) {
                    serialized.file_key = figma.fileKey;
                    serialized.root_image_base64 = rootImageBase64;
                    console.log(`✅ [Francoise Gatherer] Дерево для "${node.name}" собрано. Передаем в UI-поток.`);
                    figma.ui.postMessage({ type: 'selection-data-chunk', action: msg.action, data: serialized, sessionId: msg.sessionId });
                }
            }
            catch (e) {
                console.warn(`[Francoise Gatherer] Ошибка обработки узла:`, e);
            }
        }
        figma.ui.postMessage({ type: 'selection-gathering-complete', sessionId: msg.sessionId });
        return;
    }
    if (msg.type === 'save-validation-data') {
        const errors = msg.errors || [];
        const silent = msg.silent || false;
        const validatedFrameId = msg.validatedFrameId;
        const clearedFrameIds = msg.clearedFrameIds || [];
        const isPartial = msg.isPartial || false;
        function clearPluginData(node) {
            node.setPluginData('francoise_errors', '');
            const chunks = node.getPluginData('francoise_errors_chunks');
            if (chunks) {
                const total = parseInt(chunks, 10);
                for (let i = 0; i < total; i++)
                    node.setPluginData(`francoise_errors_${i}`, '');
                node.setPluginData('francoise_errors_chunks', '');
            }
        }
        if (validatedFrameId) {
            try {
                const frame = await figma.getNodeByIdAsync(validatedFrameId);
                if (frame && 'setPluginData' in frame)
                    clearPluginData(frame);
            }
            catch (e) { }
        }
        if (silent && clearedFrameIds.length > 0) {
            for (const fId of clearedFrameIds) {
                try {
                    const frame = await figma.getNodeByIdAsync(fId);
                    if (frame && 'setPluginData' in frame)
                        clearPluginData(frame);
                }
                catch (e) { }
            }
        }
        // Определяем "корень" для сохранения данных (строго то, что мы изначально проверяли)
        let rootContainer = null;
        try {
            if (validatedFrameId)
                rootContainer = await figma.getNodeByIdAsync(validatedFrameId);
            if (!rootContainer && figma.currentPage.selection.length > 0)
                rootContainer = figma.currentPage.selection[0];
        }
        catch (e) { }
        const frameErrorsMap = new Map();
        for (const err of errors) {
            const nodeId = (_a = err.context) === null || _a === void 0 ? void 0 : _a.node_id;
            if (nodeId) {
                try {
                    const node = await figma.getNodeByIdAsync(nodeId);
                    if (node) {
                        const sceneNode = node;
                        const bounds = sceneNode.absoluteRenderBounds || sceneNode.absoluteBoundingBox;
                        if (!err.context)
                            err.context = {};
                        err.context.y = bounds ? bounds.y : 0;
                    }
                }
                catch (e) {
                    console.log(e);
                }
            }
            // Все ошибки складываем в тот узел, с которого начали проверку
            if (rootContainer) {
                if (!err.context)
                    err.context = {};
                err.context.frame_name = rootContainer.name;
                err.context.frame_id = rootContainer.id;
                if (!frameErrorsMap.has(rootContainer))
                    frameErrorsMap.set(rootContainer, []);
                frameErrorsMap.get(rootContainer).push(err);
            }
        }
        for (const [frame, fErrors] of frameErrorsMap.entries()) {
            const jsonStr = JSON.stringify(fErrors);
            const CHUNK_SIZE = 90000;
            if (jsonStr.length > CHUNK_SIZE) {
                const totalChunks = Math.ceil(jsonStr.length / CHUNK_SIZE);
                frame.setPluginData('francoise_errors_chunks', totalChunks.toString());
                for (let i = 0; i < totalChunks; i++) {
                    const chunk = jsonStr.substring(i * CHUNK_SIZE, (i + 1) * CHUNK_SIZE);
                    frame.setPluginData(`francoise_errors_${i}`, chunk);
                }
                frame.setPluginData('francoise_errors', '');
            }
            else {
                frame.setPluginData('francoise_errors', jsonStr);
                frame.setPluginData('francoise_errors_chunks', '');
            }
        }
        if (!silent)
            figma.ui.postMessage({
                type: 'validation-enriched',
                errors: errors,
                validatedFrameId: validatedFrameId,
                isPartial: isPartial
            });
        return;
    }
    if (msg.type === 'clean-frame') {
        const frameId = msg.frameId;
        try {
            const frame = await figma.getNodeByIdAsync(frameId);
            if (frame) {
                clearAnnotationsRecursive(frame);
                figma.notify(`Очищены аннотации для: ${frame.name}`);
            }
        }
        catch (e) {
            console.warn("Фрейм для очистки не найден", e);
        }
        return;
    }
    if (msg.type === 'clean-all') {
        const selection = figma.currentPage.selection;
        if (selection.length === 0) {
            figma.notify("Пожалуйста, выделите область для очистки аннотаций");
            return;
        }
        for (const node of selection)
            clearAnnotationsRecursive(node);
        figma.notify(`Аннотации очищены в выбранной области`);
        return;
    }
    if (msg.type === 'focus-node') {
        const nodeId = msg.nodeId;
        try {
            const targetNode = await figma.getNodeByIdAsync(nodeId);
            if (targetNode) {
                figma.viewport.scrollAndZoomIntoView([targetNode]);
                figma.currentPage.selection = [targetNode];
            }
        }
        catch (e) {
            figma.notify("Оригинальный элемент больше не существует на макете");
        }
        return;
    }
    if (msg.type === 'redraw-annotations') {
        const errors = msg.errors || [];
        const clearNodeIds = msg.clearNodeIds || [];
        const isDebugMode = msg.isDebugMode || false;
        for (const id of clearNodeIds) {
            try {
                const node = await figma.getNodeByIdAsync(id);
                if (node && 'annotations' in node)
                    node.annotations = [];
            }
            catch (e) { }
        }
        if (errors.length === 0)
            return;
        const categories = await figma.annotations.getAnnotationCategoriesAsync();
        const categoryCache = new Map();
        async function getOrCreateCategory(label, color) {
            if (categoryCache.has(label))
                return categoryCache.get(label);
            let cat = categories.find(c => c.label === label);
            if (!cat)
                cat = await figma.annotations.addAnnotationCategoryAsync({ label, color });
            categoryCache.set(label, cat.id);
            return cat.id;
        }
        const groupedForCanvas = errors.reduce((acc, error) => {
            var _a;
            const id = (_a = error.context) === null || _a === void 0 ? void 0 : _a.node_id;
            if (!id)
                return acc;
            if (!acc[id])
                acc[id] = [];
            acc[id].push(error);
            return acc;
        }, {});
        let drawnCount = 0;
        for (const nodeId of Object.keys(groupedForCanvas)) {
            try {
                const targetNode = await figma.getNodeByIdAsync(nodeId);
                if (!targetNode || !('annotations' in targetNode))
                    continue;
                const newAnnotations = [];
                for (const err of groupedForCanvas[nodeId]) {
                    const isMaster = err.is_master;
                    const shortText = err.message_short || "Issue";
                    const detailedMsg = err.message_detailed || err.message || "";
                    const badgeText = isMaster ? `📂 ${shortText}` : shortText;
                    let badgeColor = err.severity === 'crit' ? 'red' : 'yellow';
                    if (isMaster)
                        badgeColor = 'orange';
                    const catId = await getOrCreateCategory(badgeText, badgeColor);
                    let bodyText = detailedMsg;
                    if (isMaster)
                        bodyText = `+${err.grouped_count} similar issues.`;
                    if (isDebugMode) {
                        const metaString = JSON.stringify(((_b = err.details) === null || _b === void 0 ? void 0 : _b.metadata) || {});
                        bodyText = `${bodyText}\n\n*Debug: ${metaString}*`;
                    }
                    newAnnotations.push({ labelMarkdown: bodyText, categoryId: catId });
                }
                targetNode.annotations = newAnnotations;
                drawnCount++;
            }
            catch (e) {
                console.warn(`Не удалось добавить аннотацию для ${nodeId}`);
            }
        }
        if (drawnCount > 0)
            figma.notify(`Отображено аннотаций: ${drawnCount}`);
        return;
    }
    if (msg.type === 'apply-fix') {
        const err = msg.error;
        const allErrors = msg.allErrors || [];
        const nodeId = (_c = err.context) === null || _c === void 0 ? void 0 : _c.node_id;
        const deletedNodeIds = new Set();
        if (!nodeId)
            return;
        try {
            const node = await figma.getNodeByIdAsync(nodeId);
            if (!node) {
                figma.notify("Элемент не найден на макете");
                return;
            }
            const childErrors = allErrors.filter((e) => {
                var _a;
                const ancestors = ((_a = e.context) === null || _a === void 0 ? void 0 : _a.ancestor_ids) || [];
                return ancestors.includes(nodeId);
            });
            const cascadingErrors = [...childErrors, err];
            cascadingErrors.sort((a, b) => {
                var _a, _b;
                const isAReplace = hasAction(a, 'replace_component');
                const isBReplace = hasAction(b, 'replace_component');
                if (isAReplace && !isBReplace)
                    return -1;
                if (!isAReplace && isBReplace)
                    return 1;
                const depthA = ((_a = a.context) === null || _a === void 0 ? void 0 : _a.depth) || 0;
                const depthB = ((_b = b.context) === null || _b === void 0 ? void 0 : _b.depth) || 0;
                if (isAReplace && isBReplace)
                    return depthA - depthB;
                return depthB - depthA;
            });
            const styleCache = new Map();
            const variableCache = new Map();
            const fixedPairs = [];
            for (const cascadeErr of cascadingErrors) {
                const cNodeId = (_d = cascadeErr.context) === null || _d === void 0 ? void 0 : _d.node_id;
                const cMeta = (_e = cascadeErr.details) === null || _e === void 0 ? void 0 : _e.metadata;
                if (!cNodeId || !cMeta)
                    continue;
                const cNode = await figma.getNodeByIdAsync(cNodeId).catch(() => null);
                if (!cNode) {
                    fixedPairs.push({ nodeId: cNodeId, issueType: (_f = cascadeErr.details) === null || _f === void 0 ? void 0 : _f.issue_type });
                    continue;
                }
                const cCommands = cMeta.actions || (cMeta.action ? [cMeta] : []);
                if (cCommands.length === 0)
                    continue;
                const isApplied = await executeFixCommands(cNode, cCommands, styleCache, variableCache, deletedNodeIds);
                if (isApplied || !cCommands.some((c) => c.action === 'bind_variable')) {
                    fixedPairs.push({ nodeId: cNodeId, issueType: (_g = cascadeErr.details) === null || _g === void 0 ? void 0 : _g.issue_type });
                }
            }
            figma.notify(`✅ Применен каскадный фикс (${fixedPairs.length} правок)`);
            figma.ui.postMessage({ type: 'fix-all-applied', fixedPairs: fixedPairs, deletedNodeIds: Array.from(deletedNodeIds) });
        }
        catch (e) {
            figma.notify("Ошибка при авто-фиксе: " + e.message);
        }
        return;
    }
    if (msg.type === 'apply-fix-all') {
        const errorsToFix = msg.errors || [];
        console.log("🚀 [Francoise Debug] Начало массового фикса. Всего ошибок:", errorsToFix.length);
        await Promise.all(errorsToFix.map(async (err) => {
            var _a;
            const nodeId = (_a = err.context) === null || _a === void 0 ? void 0 : _a.node_id;
            if (nodeId) {
                try {
                    const node = await figma.getNodeByIdAsync(nodeId);
                    if (node) {
                        let depth = 0;
                        let parent = node.parent;
                        const ancestors = [];
                        while (parent && parent.type !== 'PAGE' && parent.type !== 'DOCUMENT') {
                            depth++;
                            ancestors.push(parent.id);
                            parent = parent.parent;
                        }
                        if (!err.context)
                            err.context = {};
                        err.context.depth = depth;
                        err.context.ancestor_ids = ancestors;
                    }
                }
                catch (e) { }
            }
        }));
        const nodesBeingReplaced = new Set();
        errorsToFix.forEach((err) => {
            var _a, _b;
            if (hasAction(err, 'replace_component')) {
                if ((_a = err.context) === null || _a === void 0 ? void 0 : _a.node_id)
                    nodesBeingReplaced.add(err.context.node_id);
                const meta = (_b = err.details) === null || _b === void 0 ? void 0 : _b.metadata;
                const commands = (meta === null || meta === void 0 ? void 0 : meta.actions) || ((meta === null || meta === void 0 ? void 0 : meta.action) ? [meta] : []);
                commands.forEach((c) => {
                    var _a;
                    if (c.action === 'replace_component' && ((_a = c.payload) === null || _a === void 0 ? void 0 : _a.nodes_to_remove)) {
                        c.payload.nodes_to_remove.forEach((id) => nodesBeingReplaced.add(id));
                    }
                });
            }
        });
        const prunedErrors = errorsToFix.filter((err) => {
            var _a, _b;
            if (hasAction(err, 'replace_component'))
                return true;
            const nodeId = (_a = err.context) === null || _a === void 0 ? void 0 : _a.node_id;
            const ancestors = ((_b = err.context) === null || _b === void 0 ? void 0 : _b.ancestor_ids) || [];
            return !(nodesBeingReplaced.has(nodeId) || ancestors.some((id) => nodesBeingReplaced.has(id)));
        });
        const structuralActions = [];
        const layoutActions = [];
        for (const err of prunedErrors) {
            const meta = (_h = err.details) === null || _h === void 0 ? void 0 : _h.metadata;
            // Используем опциональную цепочку (?.) для защиты от undefined
            const commands = (meta === null || meta === void 0 ? void 0 : meta.actions) || ((meta === null || meta === void 0 ? void 0 : meta.action) ? [meta] : []);
            // 🚀 ИСПРАВЛЕНИЕ: Если команд нет, игнорируем эту ошибку
            if (!commands || commands.length === 0)
                continue;
            if (commands.some((c) => c.action === 'apply_auto_layout')) {
                layoutActions.push({ err, commands });
            }
            else {
                structuralActions.push({ err, commands });
            }
        }
        structuralActions.sort((a, b) => { var _a, _b; return (((_a = b.err.context) === null || _a === void 0 ? void 0 : _a.depth) || 0) - (((_b = a.err.context) === null || _b === void 0 ? void 0 : _b.depth) || 0); });
        layoutActions.sort((a, b) => { var _a, _b; return (((_a = a.err.context) === null || _a === void 0 ? void 0 : _a.depth) || 0) - (((_b = b.err.context) === null || _b === void 0 ? void 0 : _b.depth) || 0); });
        const fixedPairs = [];
        const styleCache = new Map();
        const variableCache = new Map();
        const deletedNodeIds = new Set();
        for (const item of structuralActions) {
            const node = await figma.getNodeByIdAsync(item.err.context.node_id);
            if (node) {
                await executeFixCommands(node, item.commands, styleCache, variableCache, deletedNodeIds);
                fixedPairs.push({ nodeId: node.id, issueType: (_j = item.err.details) === null || _j === void 0 ? void 0 : _j.issue_type });
            }
        }
        for (const item of layoutActions) {
            const node = await figma.getNodeByIdAsync(item.err.context.node_id);
            if (node) {
                await executeFixCommands(node, item.commands, styleCache, variableCache, deletedNodeIds);
                fixedPairs.push({ nodeId: node.id, issueType: (_k = item.err.details) === null || _k === void 0 ? void 0 : _k.issue_type });
            }
        }
        const absorbedPairs = errorsToFix
            .filter((e) => !prunedErrors.includes(e))
            .map((e) => { var _a, _b; return ({ nodeId: (_a = e.context) === null || _a === void 0 ? void 0 : _a.node_id, issueType: (_b = e.details) === null || _b === void 0 ? void 0 : _b.issue_type }); });
        figma.notify(`✅ Применено правок: ${fixedPairs.length}`);
        figma.ui.postMessage({ type: 'fix-all-applied', fixedPairs: [...fixedPairs, ...absorbedPairs], deletedNodeIds: Array.from(deletedNodeIds) });
        return;
    }
    if (msg.type === 'run-benchmark') {
        const benchmarkPages = figma.root.children.filter(p => p.name.startsWith('DS Benchmark'));
        if (benchmarkPages.length === 0) {
            figma.notify("Страница бенчмарка не найдена. Сначала сгенерируйте её.");
            figma.ui.postMessage({ type: 'benchmark-aborted' });
            return;
        }
        const benchmarkPage = benchmarkPages[benchmarkPages.length - 1];
        const chunks = benchmarkPage.children.filter(c => c.type === 'FRAME');
        if (chunks.length === 0) {
            figma.notify("На странице бенчмарка нет фреймов.");
            figma.ui.postMessage({ type: 'benchmark-aborted' });
            return;
        }
        figma.notify(`Запуск бенчмарка: сканируем ${chunks.length} групп...`);
        console.log(`[Francoise Benchmark] Старт сбора данных. Чанков: ${chunks.length}`);
        for (let i = 0; i < chunks.length; i++) {
            const chunk = chunks[i];
            const rootImageBytes = await chunk.exportAsync({ format: 'JPG', constraint: { type: 'SCALE', value: 2 } });
            const rootImageBase64 = figma.base64Encode(rootImageBytes);
            totalNodesScanned = 0;
            const serialized = await serializeNode(chunk);
            if (serialized) {
                serialized.file_key = figma.fileKey;
                serialized.root_image_base64 = rootImageBase64;
                figma.ui.postMessage({ type: 'benchmark-chunk', data: serialized, chunkIndex: i, totalChunks: chunks.length });
            }
        }
        return;
    }
    if (msg.type === 'draw-benchmark-marks') {
        const fails = msg.fails || [];
        if (fails.length === 0)
            return;
        async function drawBenchmarkMarks() {
            try {
                await figma.loadFontAsync({ family: "Inter", style: "Regular" });
                await figma.loadFontAsync({ family: "Inter", style: "Bold" });
                const markerNodes = [];
                for (const fail of fails) {
                    try {
                        const targetNode = await figma.getNodeByIdAsync(fail.nodeId);
                        if (!targetNode)
                            continue;
                        const bounds = 'absoluteBoundingBox' in targetNode ? targetNode.absoluteBoundingBox : null;
                        if (!bounds)
                            continue;
                        const isL2 = fail.actual.includes('L2');
                        const badge = figma.createFrame();
                        badge.name = `[Benchmark] ${isL2 ? 'L2 Miss' : 'L0 Miss'}`;
                        badge.layoutMode = 'VERTICAL';
                        badge.paddingLeft = badge.paddingRight = badge.paddingTop = badge.paddingBottom = 8;
                        badge.itemSpacing = 4;
                        badge.cornerRadius = 6;
                        badge.fills = [{ type: 'SOLID', color: isL2 ? { r: 0.96, g: 0.65, b: 0.14 } : { r: 0.9, g: 0.2, b: 0.2 } }];
                        const titleText = figma.createText();
                        titleText.fontName = { family: "Inter", style: "Bold" };
                        titleText.characters = isL2 ? '⚠️ L2 Match (Not Ideal)' : '❌ L0 Miss';
                        titleText.fills = [{ type: 'SOLID', color: { r: 1, g: 1, b: 1 } }];
                        titleText.fontSize = 11;
                        badge.appendChild(titleText);
                        const detailsText = figma.createText();
                        detailsText.fontName = { family: "Inter", style: "Regular" };
                        detailsText.characters = `Expected: ${fail.expected}\nActual: ${fail.actual}\nRule: ${fail.rule}`;
                        detailsText.fills = [{ type: 'SOLID', color: { r: 1, g: 1, b: 1 } }];
                        detailsText.fontSize = 10;
                        badge.appendChild(detailsText);
                        badge.x = bounds.x + bounds.width + 16;
                        badge.y = bounds.y;
                        figma.currentPage.appendChild(badge);
                        markerNodes.push(badge);
                    }
                    catch (e) {
                        console.warn(`[Benchmark] Пропуск отрисовки узла ${fail.nodeId}`, e);
                    }
                }
                if (markerNodes.length > 0) {
                    const group = figma.group(markerNodes, figma.currentPage);
                    group.name = `📊 Benchmark Discrepancies [${new Date().toLocaleTimeString()}]`;
                    group.locked = true;
                    figma.notify(`Отрисовано ${markerNodes.length} маркеров расхождений бенчмарка`);
                }
            }
            catch (err) {
                console.error("Ошибка при генерации маркеров бенчмарка", err);
            }
        }
        drawBenchmarkMarks();
    }
    if (msg.type === 'save-api-key') {
        await figma.clientStorage.setAsync('francoise_api_key', msg.apiKey);
        return;
    }
    if (msg.type === 'resize-window') {
        // Если expanded = true, делаем плагин высоким (500px), иначе стандартным (320px)
        figma.ui.resize(320, msg.expanded ? 500 : 320);
        return;
    }
    if (msg.type === 'check-space') {
        try {
            // Читаем массив (поддерживаем обратную совместимость)
            const frameIds = msg.frameIds || (msg.frameId ? [msg.frameId] : []);
            let hasSpace = false;
            for (const fId of frameIds) {
                const targetNode = await figma.getNodeByIdAsync(fId);
                if (targetNode) {
                    const space = getFreeSpaceForNode(targetNode);
                    if (space.hasSpace) {
                        hasSpace = true;
                        break; // Нашли место хотя бы для одного — превью возможно!
                    }
                }
            }
            figma.ui.postMessage({ type: 'space-result', hasSpace: hasSpace });
        }
        catch (e) {
            figma.ui.postMessage({ type: 'space-result', hasSpace: false });
        }
        return;
    }
    if (msg.type === 'generate-preview') {
        const { frameIds, errorsToFix } = msg;
        try {
            const idMap = new Map();
            const cloneIds = [];
            for (const fId of frameIds) {
                const targetNode = await figma.getNodeByIdAsync(fId);
                if (!targetNode || !('absoluteBoundingBox' in targetNode) || !targetNode.absoluteBoundingBox)
                    continue;
                const space = getFreeSpaceForNode(targetNode);
                if (!space.hasSpace)
                    continue;
                const clone = targetNode.clone();
                clone.name = `[Preview] ${targetNode.name}`;
                clone.x = space.x;
                clone.y = space.y;
                // 💡 Убрали clone.locked = true, чтобы дизайнер мог покликать по слоям превью
                // 🧹 Сразу очищаем клон от скопированных аннотаций и кэша ошибок
                clearAnnotationsRecursive(clone);
                figma.currentPage.appendChild(clone);
                cloneIds.push(clone.id);
                buildCloneMap(targetNode, clone, idMap);
            }
            if (cloneIds.length === 0) {
                figma.ui.postMessage({ type: 'preview-aborted' });
                return;
            }
            const firstClone = await figma.getNodeByIdAsync(cloneIds[0]);
            if (firstClone)
                figma.viewport.scrollAndZoomIntoView([firstClone]);
            const mappedErrors = mapErrorsToClone(errorsToFix, idMap);
            // Белый список всех ID, которые принадлежат ТОЛЬКО клонам
            const allCloneIds = new Set(idMap.values());
            const styleCache = new Map();
            const variableCache = new Map();
            const deletedNodeIds = new Set();
            const createdNodeIds = new Set(); // Сюда упадут новые инстансы от replace_component
            for (const err of mappedErrors) {
                const meta = (_l = err.details) === null || _l === void 0 ? void 0 : _l.metadata;
                const commands = (meta === null || meta === void 0 ? void 0 : meta.actions) || ((meta === null || meta === void 0 ? void 0 : meta.action) ? [meta] : []);
                if (!commands.length)
                    continue;
                const cloneNodeToFix = await figma.getNodeByIdAsync(err.context.node_id);
                // Запускаем фикс ТОЛЬКО если целевой узел находится в белом списке клонов
                if (cloneNodeToFix && allCloneIds.has(cloneNodeToFix.id)) {
                    await executeFixCommands(cloneNodeToFix, commands, styleCache, variableCache, deletedNodeIds, allCloneIds, createdNodeIds);
                }
            }
            // Объединяем оригинальные клоны и те узлы, что родились в процессе (replace_component)
            const finalCloneIds = [...cloneIds, ...Array.from(createdNodeIds)];
            figma.ui.postMessage({ type: 'preview-generated', cloneIds: finalCloneIds });
        }
        catch (e) {
            console.error("Preview generation failed:", e);
        }
        return;
    }
    if (msg.type === 'cleanup-preview') {
        try {
            if (msg.cloneIds && Array.isArray(msg.cloneIds)) {
                for (const cloneId of msg.cloneIds) {
                    const clone = await figma.getNodeByIdAsync(cloneId);
                    if (clone && !('removed' in clone && clone.removed))
                        clone.remove();
                }
            }
        }
        catch (e) { }
        return;
    }
    if (msg.type === 'set-group-state') {
        const selection = figma.currentPage.selection;
        for (const node of selection) {
            node.setPluginData('francoise_is_grouped', msg.isGrouped ? 'true' : 'false');
        }
        return;
    }
    if (msg.type === 'notify') {
        figma.notify(msg.message);
        return;
    }
    if (msg.type === 'refresh-state') {
        notifySelectionUpdate();
        return;
    }
};
// ==========================================
// --- 4. ИСПОЛНИТЕЛЬНАЯ ЛОГИКА АВТО-ФИКСОВ -
// ==========================================
async function executeFixCommands(node, commands, styleCache, variableCache, deletedNodeIds, allowedNodeIds, createdNodeIds) {
    var _a;
    let isApplied = false;
    function clone(val) { return JSON.parse(JSON.stringify(val)); }
    for (const cmd of commands) {
        const action = cmd.action;
        const payload = cmd.payload || {};
        switch (action) {
            case 'bind_variable': {
                let styleId = null;
                let variableObj = null;
                if (payload.token_type === 'STYLE') {
                    if (styleCache.has(payload.token_key))
                        styleId = styleCache.get(payload.token_key);
                    else {
                        try {
                            styleId = (await figma.importStyleByKeyAsync(payload.token_key)).id;
                        }
                        catch (e) {
                            try {
                                styleId = (_a = (await figma.getStyleByIdAsync(payload.token_id))) === null || _a === void 0 ? void 0 : _a.id;
                            }
                            catch (err) { }
                        }
                        if (styleId)
                            styleCache.set(payload.token_key, styleId);
                    }
                }
                else if (payload.token_type === 'VARIABLE') {
                    if (variableCache.has(payload.token_key))
                        variableObj = variableCache.get(payload.token_key);
                    else {
                        try {
                            variableObj = await figma.variables.importVariableByKeyAsync(payload.token_key);
                        }
                        catch (e) {
                            try {
                                variableObj = await figma.variables.getVariableByIdAsync(payload.token_id);
                            }
                            catch (err) { }
                        }
                        if (variableObj)
                            variableCache.set(payload.token_key, variableObj);
                    }
                }
                if (payload.target_property === 'typography' && styleId && node.type === 'TEXT') {
                    await safelyLoadTextNodeFonts(node);
                    await node.setTextStyleIdAsync(styleId);
                    isApplied = true;
                }
                else if (payload.target_property === 'fills' && 'fills' in node) {
                    if (styleId) {
                        node.fillStyleId = styleId;
                        isApplied = true;
                    }
                    else if (variableObj && node.fills !== figma.mixed && Array.isArray(node.fills)) {
                        const fills = clone(node.fills);
                        const paintIdx = payload.paint_index !== undefined ? payload.paint_index : 0;
                        if (paintIdx < fills.length) {
                            const targetPaint = fills[paintIdx];
                            // 🚀 Если передан индекс точки градиента
                            if (payload.stop_index !== undefined && 'gradientStops' in targetPaint) {
                                const stopIdx = payload.stop_index;
                                if (stopIdx < targetPaint.gradientStops.length) {
                                    const alias = figma.variables.createVariableAlias(variableObj);
                                    const newStops = [...targetPaint.gradientStops];
                                    const newStop = Object.assign({}, newStops[stopIdx]);
                                    newStop.boundVariables = Object.assign(Object.assign({}, (newStop.boundVariables || {})), { color: alias });
                                    newStops[stopIdx] = newStop;
                                    targetPaint.gradientStops = newStops;
                                    fills[paintIdx] = targetPaint;
                                    node.fills = fills;
                                    isApplied = true;
                                }
                            }
                            // 🚀 Обычная сплошная заливка
                            else if (targetPaint.type === 'SOLID') {
                                fills[paintIdx] = figma.variables.setBoundVariableForPaint(targetPaint, 'color', variableObj);
                                node.fills = fills;
                                isApplied = true;
                            }
                        }
                    }
                }
                else if (payload.target_property === 'strokes' && 'strokes' in node) {
                    if (styleId) {
                        node.strokeStyleId = styleId;
                        isApplied = true;
                    }
                    else if (variableObj && node.strokes !== figma.mixed && Array.isArray(node.strokes)) {
                        const strokes = clone(node.strokes);
                        const paintIdx = payload.paint_index !== undefined ? payload.paint_index : 0;
                        if (paintIdx < strokes.length) {
                            const targetPaint = strokes[paintIdx];
                            // Если передан индекс точки градиента
                            if (payload.stop_index !== undefined && 'gradientStops' in targetPaint) {
                                const stopIdx = payload.stop_index;
                                if (stopIdx < targetPaint.gradientStops.length) {
                                    const alias = figma.variables.createVariableAlias(variableObj);
                                    const newStops = [...targetPaint.gradientStops];
                                    const newStop = Object.assign({}, newStops[stopIdx]);
                                    newStop.boundVariables = Object.assign(Object.assign({}, (newStop.boundVariables || {})), { color: alias });
                                    newStops[stopIdx] = newStop;
                                    targetPaint.gradientStops = newStops;
                                    strokes[paintIdx] = targetPaint;
                                    node.strokes = strokes;
                                    isApplied = true;
                                }
                            }
                            // 🚀 Обычная сплошная обводка
                            else if (targetPaint.type === 'SOLID') {
                                strokes[paintIdx] = figma.variables.setBoundVariableForPaint(targetPaint, 'color', variableObj);
                                node.strokes = strokes;
                                isApplied = true;
                            }
                        }
                    }
                }
                else if (payload.target_property === 'itemSpacing' && variableObj && 'itemSpacing' in node) {
                    node.setBoundVariable('itemSpacing', variableObj);
                    isApplied = true;
                }
                else if (payload.target_property === 'paddingVertical' && variableObj && 'paddingTop' in node) {
                    node.setBoundVariable('paddingTop', variableObj);
                    node.setBoundVariable('paddingBottom', variableObj);
                    isApplied = true;
                }
                else if (payload.target_property === 'paddingHorizontal' && variableObj && 'paddingLeft' in node) {
                    node.setBoundVariable('paddingLeft', variableObj);
                    node.setBoundVariable('paddingRight', variableObj);
                    isApplied = true;
                }
                else if (payload.target_property === 'paddingTop' && variableObj && 'paddingTop' in node) {
                    node.setBoundVariable('paddingTop', variableObj);
                    isApplied = true;
                }
                else if (payload.target_property === 'paddingBottom' && variableObj && 'paddingBottom' in node) {
                    node.setBoundVariable('paddingBottom', variableObj);
                    isApplied = true;
                }
                else if (payload.target_property === 'paddingLeft' && variableObj && 'paddingLeft' in node) {
                    node.setBoundVariable('paddingLeft', variableObj);
                    isApplied = true;
                }
                else if (payload.target_property === 'paddingRight' && variableObj && 'paddingRight' in node) {
                    node.setBoundVariable('paddingRight', variableObj);
                    isApplied = true;
                }
                else if (payload.target_property === 'padding' && variableObj && 'paddingTop' in node) {
                    node.setBoundVariable('paddingTop', variableObj);
                    node.setBoundVariable('paddingBottom', variableObj);
                    node.setBoundVariable('paddingLeft', variableObj);
                    node.setBoundVariable('paddingRight', variableObj);
                    isApplied = true;
                }
                break;
            }
            case 'suggest_icon_replacement': {
                const componentKey = payload.replacement_component_key;
                const componentId = payload.replacement_component_id;
                let newIconComponent = null;
                if (componentId) {
                    try {
                        const localNode = await figma.getNodeByIdAsync(componentId);
                        if (localNode && localNode.type === 'COMPONENT')
                            newIconComponent = localNode;
                    }
                    catch (e) { }
                }
                if (!newIconComponent && componentKey && componentKey !== "None") {
                    try {
                        newIconComponent = await figma.importComponentByKeyAsync(componentKey);
                    }
                    catch (e) {
                        console.warn(`[Francoise] External import failed for key ${componentKey}`);
                    }
                }
                if (newIconComponent) {
                    try {
                        const newInstance = newIconComponent.createInstance();
                        newInstance.x = node.x;
                        newInstance.y = node.y;
                        newInstance.resize(node.width, node.height);
                        if ('layoutAlign' in node)
                            newInstance.layoutAlign = node.layoutAlign;
                        if ('layoutPositioning' in node)
                            newInstance.layoutPositioning = node.layoutPositioning;
                        if ('layoutGrow' in node)
                            newInstance.layoutGrow = node.layoutGrow;
                        const parent = node.parent;
                        if (parent) {
                            const index = parent.children.indexOf(node);
                            parent.insertChild(index, newInstance);
                        }
                        node.remove();
                        deletedNodeIds.add(node.id);
                        isApplied = true;
                    }
                    catch (e) {
                        figma.notify("Ошибка при вставке иконки на макет.", { error: true });
                    }
                }
                else {
                    figma.notify("Компонент иконки не найден ни локально, ни в библиотеке.", { error: true });
                }
                break;
            }
            case 'set_resizing': {
                if (node.type === 'TEXT' && payload.textAutoResize) {
                    const resize = safeEnum(payload.textAutoResize, ['NONE', 'WIDTH_AND_HEIGHT', 'HEIGHT', 'TRUNCATE']);
                    if (resize) {
                        node.textAutoResize = resize;
                        isApplied = true;
                    }
                }
                if ('primaryAxisSizingMode' in node && payload.primaryAxisSizingMode) {
                    const mode = safeEnum(payload.primaryAxisSizingMode, ['FIXED', 'AUTO']);
                    if (mode) {
                        node.primaryAxisSizingMode = mode;
                        isApplied = true;
                    }
                }
                if ('counterAxisSizingMode' in node && payload.counterAxisSizingMode) {
                    const mode = safeEnum(payload.counterAxisSizingMode, ['FIXED', 'AUTO']);
                    if (mode) {
                        node.counterAxisSizingMode = mode;
                        isApplied = true;
                    }
                }
                if ('layoutAlign' in node && payload.layoutAlign) {
                    const align = safeEnum(payload.layoutAlign, ['MIN', 'CENTER', 'MAX', 'STRETCH', 'INHERIT']);
                    if (align) {
                        node.layoutAlign = align;
                        isApplied = true;
                    }
                }
                if ('layoutGrow' in node && payload.layoutGrow !== undefined) {
                    node.layoutGrow = safeGrow(payload.layoutGrow);
                    isApplied = true;
                }
                if ('resize' in node && (payload.width !== undefined || payload.height !== undefined)) {
                    const w = safeNum(payload.width, 0.01, node.width);
                    const h = safeNum(payload.height, 0.01, node.height);
                    node.resize(w, h);
                    isApplied = true;
                }
                const sidePaddings = ['paddingTop', 'paddingBottom', 'paddingLeft', 'paddingRight'];
                sidePaddings.forEach(prop => {
                    if (prop in node && payload[prop] !== undefined) {
                        node[prop] = safeNum(payload[prop], 0, node[prop]);
                        isApplied = true;
                    }
                });
                break;
            }
            case 'apply_auto_layout': {
                if ('layoutMode' in node) {
                    if (payload.direction)
                        node.layoutMode = payload.direction;
                    if (payload.primary_align)
                        node.primaryAxisAlignItems = payload.primary_align;
                    if (payload.counter_align)
                        node.counterAxisAlignItems = payload.counter_align;
                    if (payload.fallback_spacing !== undefined && payload.fallback_spacing !== null) {
                        const spacingVal = parseFloat(payload.fallback_spacing);
                        if (!isNaN(spacingVal))
                            node.itemSpacing = spacingVal;
                    }
                    isApplied = true;
                }
                break;
            }
            case 'trim_whitespace': {
                if (node.type === 'TEXT' && payload.cleaned_text) {
                    await figma.loadFontAsync(node.fontName);
                    node.characters = payload.cleaned_text;
                    isApplied = true;
                }
                break;
            }
            case 'remove_absolute_position': {
                if ('layoutPositioning' in node) {
                    node.layoutPositioning = 'AUTO';
                    isApplied = true;
                }
                break;
            }
            case 'replace_component': {
                const { target_instance_id, replacement_component_key, replacement_component_id, legal_state, nodes_to_remove } = payload;
                // 🔒 ЖЕЛЕЗОБЕТОННАЯ ЗАЩИТА: Если мы в режиме превью и ID нет в белом списке клонов — блокируем!
                if (allowedNodeIds && !allowedNodeIds.has(target_instance_id)) {
                    console.warn(`[Preview Protection] Blocked replacement of original node ${target_instance_id}`);
                    return false;
                }
                const oldNode = await figma.getNodeByIdAsync(target_instance_id);
                if (!oldNode) {
                    return false;
                }
                let master = null;
                if (replacement_component_id) {
                    console.log(`🔍 [Francoise] Ищем локально по ID: ${replacement_component_id}`);
                    try {
                        const localNode = await figma.getNodeByIdAsync(replacement_component_id);
                        if (localNode) {
                            console.log(`✅ [Francoise] Локальный узел найден! Тип: ${localNode.type}, Имя: ${localNode.name}`);
                            if (localNode.type === 'COMPONENT') {
                                master = localNode;
                                console.log(`🎯 [Francoise] Это COMPONENT. Мастер успешно установлен.`);
                            }
                            else if (localNode.type === 'COMPONENT_SET') {
                                master = localNode.defaultVariant;
                                console.log(`🎯 [Francoise] Это COMPONENT_SET. Взяли defaultVariant. Мастер успешно установлен.`);
                            }
                            else {
                                console.warn(`⚠️ [Francoise] Локальный узел найден, но его тип ${localNode.type}, а не COMPONENT или COMPONENT_SET!`);
                            }
                        }
                        else {
                            console.warn(`⚠️ [Francoise] getNodeByIdAsync вернул null для ID: ${replacement_component_id}`);
                        }
                    }
                    catch (e) {
                        console.warn(`❌ [Francoise] Исключение при локальном поиске:`, e);
                    }
                }
                if (!master && replacement_component_key && replacement_component_key !== "None") {
                    console.log(`🌐 [Francoise] Локальный мастер не установлен. Пробуем сетевой импорт по ключу: ${replacement_component_key}`);
                    try {
                        master = await figma.importComponentByKeyAsync(replacement_component_key);
                        console.log(`✅ [Francoise] Сетевой импорт успешен!`);
                    }
                    catch (e) {
                        console.error(`❌ [Francoise] 404/403 Не удалось импортировать по ключу ${replacement_component_key}`, e);
                    }
                }
                if (!master) {
                    console.error(`💀 [Francoise] ФАТАЛ: Мастер-компонент не найден ни локально, ни в библиотеке.`);
                    figma.notify("Мастер-компонент не найден ни локально, ни в библиотеке.", { error: true });
                    return false;
                }
                console.log(`🏗️ [Francoise] Приступаем к инстанцированию...`);
                const newInstance = master.createInstance();
                if (createdNodeIds)
                    createdNodeIds.add(newInstance.id); // Запоминаем, чтобы потом удалить!
                const targetInstanceForState = newInstance;
                if (payload.variant_properties && Object.keys(payload.variant_properties).length > 0) {
                    try {
                        newInstance.setProperties(payload.variant_properties);
                    }
                    catch (e) {
                        console.warn("[Francoise] Не удалось применить свойства варианта:", e);
                    }
                }
                // 🚀 ВОССТАНОВЛЕНИЕ ТЕКСТОВЫХ ОВЕРРАЙДОВ
                if (payload.text_overrides) {
                    try {
                        const textNodes = newInstance.findAll(n => n.type === "TEXT");
                        for (const textNode of textNodes) {
                            const savedText = payload.text_overrides[textNode.name];
                            if (savedText && savedText !== textNode.characters) {
                                try {
                                    await figma.loadFontAsync(textNode.fontName);
                                    textNode.characters = savedText;
                                }
                                catch (e) {
                                    console.warn("Failed to load font for text override", e);
                                }
                            }
                        }
                    }
                    catch (e) {
                        console.warn("Failed to apply text overrides", e);
                    }
                }
                const parent = oldNode.parent;
                const oldIndex = parent && parent.type !== 'INSTANCE' ? parent.children.findIndex(c => c.id === oldNode.id) : -1;
                const isInsideAL = parent && 'layoutMode' in parent && parent.layoutMode !== 'NONE';
                const isOldAbsolute = 'layoutPositioning' in oldNode && oldNode.layoutPositioning === 'ABSOLUTE';
                if (isOldAbsolute && 'layoutPositioning' in newInstance)
                    newInstance.layoutPositioning = 'ABSOLUTE';
                if (!isInsideAL || isOldAbsolute) {
                    newInstance.x = oldNode.x;
                    newInstance.y = oldNode.y;
                }
                if (parent && oldIndex !== -1)
                    parent.insertChild(oldIndex, newInstance);
                else if (parent)
                    parent.appendChild(newInstance);
                if (legal_state && Array.isArray(legal_state)) {
                    for (const item of legal_state) {
                        const props = item.properties || {};
                        if (props.is_dynamic_content && (props.items || props.characters)) {
                            const parts = item.path.split(" > ");
                            const lastPart = parts[parts.length - 1];
                            const parentPath = parts.length > 1 ? parts.slice(0, -1).join(" > ") : "root";
                            const parentNode = findNodeByRelativePath(targetInstanceForState, parentPath) || targetInstanceForState;
                            if (parentNode && 'children' in parentNode) {
                                const itemNameMatch = lastPart.match(/(.+)\[.*\]/);
                                const itemName = itemNameMatch ? itemNameMatch[1] : lastPart.replace(/\[.*\]/, "");
                                let targetChildren = parentNode.children.filter((c) => c.type === 'INSTANCE' && (itemName === "{*}" || c.name.includes(itemName)));
                                if (targetChildren.length === 0)
                                    targetChildren = parentNode.children.filter((c) => c.type === 'INSTANCE');
                                const itemsData = props.items || props.characters.map((text) => ({ text }));
                                console.log(`📊 [Dynamic Content]: Пытаемся заполнить ${itemsData.length} элементов в "${parentNode.name}". Найдено слотов: ${targetChildren.length}. Искомое имя: ${itemName}`);
                                for (let i = 0; i < targetChildren.length; i++) {
                                    const childInstance = targetChildren[i];
                                    if (i < itemsData.length) {
                                        childInstance.visible = true;
                                        const itemData = itemsData[i];
                                        if (itemData.text) {
                                            const textNode = childInstance.findOne((n) => n.type === 'TEXT');
                                            if (textNode) {
                                                await safelyLoadTextNodeFonts(textNode);
                                                textNode.characters = itemData.text;
                                            }
                                        }
                                        if (itemData.icon_key) {
                                            try {
                                                const iconSlot = childInstance.findOne((n) => n.type === 'INSTANCE' && n.name.toLowerCase().includes('icon'));
                                                if (iconSlot) {
                                                    const newIconMaster = await figma.importComponentByKeyAsync(itemData.icon_key);
                                                    if (newIconMaster) {
                                                        iconSlot.swapComponent(newIconMaster);
                                                        iconSlot.visible = true;
                                                    }
                                                }
                                            }
                                            catch (e) {
                                                console.warn("Иконка не найдена", e);
                                            }
                                        }
                                        if (!itemData.text && itemData.icon_key) {
                                            const textNode = childInstance.findOne((n) => n.type === 'TEXT');
                                            if (textNode)
                                                textNode.visible = false;
                                        }
                                    }
                                    else {
                                        childInstance.visible = false;
                                    }
                                }
                            }
                            continue;
                        }
                        const targetSlot = findNodeByRelativePath(targetInstanceForState, item.path);
                        if (!targetSlot) {
                            console.warn(`⚠️ [Francoise Path Error]: Слот не найден! Путь: "${item.path}". Ожидаемый тип: ${item.node_type}`);
                            continue;
                        }
                        else {
                            console.log(`✅ [Francoise Path OK]: Найден слот "${targetSlot.name}" по пути "${item.path}"`);
                        }
                        if (item.path === "root") {
                            if (props.componentProperties && targetSlot.type === 'INSTANCE') {
                                const oldProps = props.componentProperties;
                                const newProps = targetSlot.componentProperties;
                                const propsToApply = {};
                                const cleanName = (name) => name.split('#')[0].trim();
                                const newPropsLookup = new Map();
                                for (const newKey of Object.keys(newProps))
                                    newPropsLookup.set(cleanName(newKey), { key: newKey, type: newProps[newKey].type });
                                for (const [oldKey, oldProp] of Object.entries(oldProps)) {
                                    const matchedNewProp = newPropsLookup.get(cleanName(oldKey));
                                    if (matchedNewProp && matchedNewProp.type === oldProp.type)
                                        propsToApply[matchedNewProp.key] = oldProp.value;
                                }
                                if (Object.keys(propsToApply).length > 0) {
                                    try {
                                        targetSlot.setProperties(propsToApply);
                                    }
                                    catch (e) {
                                        console.warn("[Francoise] Ошибка применения пропсов:", e);
                                    }
                                }
                            }
                            continue;
                        }
                        if (item.path !== "root") {
                            if (props.characters !== undefined) {
                                let textNodeToUpdate = null;
                                if (targetSlot.type === 'TEXT')
                                    textNodeToUpdate = targetSlot;
                                else if ('findOne' in targetSlot)
                                    textNodeToUpdate = targetSlot.findOne((n) => n.type === 'TEXT');
                                if (textNodeToUpdate) {
                                    await safelyLoadTextNodeFonts(textNodeToUpdate);
                                    textNodeToUpdate.characters = props.characters;
                                    console.log(`✅ [Text Update]: Текст изменен на "${props.characters}"`);
                                }
                                else {
                                    console.warn(`⚠️ [Text Update Error]: Внутри слота "${targetSlot.name}" нет текстовых примитивов!`);
                                }
                            }
                            if (item.node_type === 'INSTANCE' && props.master_component_key && targetSlot.type === 'INSTANCE') {
                                try {
                                    const newNestedMaster = await figma.importComponentByKeyAsync(props.master_component_key);
                                    if (newNestedMaster) {
                                        targetSlot.swapComponent(newNestedMaster);
                                    }
                                }
                                catch (e) { }
                            }
                            continue;
                        }
                    }
                }
                if (nodes_to_remove && Array.isArray(nodes_to_remove)) {
                    for (const idToRemove of nodes_to_remove) {
                        if (idToRemove === oldNode.id)
                            continue;
                        try {
                            const nodeToKill = await figma.getNodeByIdAsync(idToRemove);
                            if (nodeToKill && !('removed' in nodeToKill && nodeToKill.removed)) {
                                nodeToKill.remove();
                                deletedNodeIds.add(idToRemove);
                            }
                        }
                        catch (e) { }
                    }
                }
                if (!oldNode.removed) {
                    oldNode.remove();
                    deletedNodeIds.add(oldNode.id);
                }
                isApplied = true;
                break;
            }
            case 'fix_typo': {
                if (node.type === 'TEXT' && payload.suggested_text) {
                    try {
                        await safelyLoadTextNodeFonts(node);
                        node.characters = payload.suggested_text;
                        isApplied = true;
                    }
                    catch (e) {
                        console.warn(`[Francoise] Ошибка применения шрифта для ${node.name}:`, e);
                    }
                }
                break;
            }
            case 'fix_layer_name': {
                if (payload.suggested_text) {
                    node.name = payload.suggested_text;
                    node.setPluginData('francoise_approved_name', payload.suggested_text);
                    isApplied = true;
                }
                break;
            }
        }
    }
    return isApplied;
}
// ==========================================
// --- 5. СОБЫТИЯ И ПОМОЩНИКИ ФИГМЫ ---------
// ==========================================
function checkEnvironment() {
    const isDraft = !figma.fileKey;
    figma.ui.postMessage({ type: 'env-status', isDraft: isDraft });
}
function notifySelectionUpdate() {
    const selection = figma.currentPage.selection;
    const rawSelectedIds = selection.map(n => n.id);
    // 🚀 НОВОЕ: Собираем ID корневых элементов для каждого выделенного узла
    const rootSelectedIds = Array.from(new Set(selection.map(node => {
        let current = node;
        // Поднимаемся вверх, пока не упремся в страницу или холст
        while (current.parent && current.parent.type !== 'PAGE' && current.parent.type !== 'DOCUMENT') {
            current = current.parent;
        }
        return current.id;
    })));
    let loadedErrors = [];
    const processedNodes = new Set();
    function collectErrorsRecursive(node) {
        if (processedNodes.has(node.id))
            return;
        processedNodes.add(node.id);
        let jsonStr = '';
        const chunksCountStr = node.getPluginData('francoise_errors_chunks');
        if (chunksCountStr) {
            const totalChunks = parseInt(chunksCountStr, 10);
            for (let i = 0; i < totalChunks; i++)
                jsonStr += node.getPluginData(`francoise_errors_${i}`);
        }
        else {
            jsonStr = node.getPluginData('francoise_errors');
        }
        if (jsonStr) {
            try {
                const parsed = JSON.parse(jsonStr);
                parsed.forEach((err) => { if (!err.context)
                    err.context = {}; err.context.frame_name = node.name; err.context.frame_id = node.id; });
                loadedErrors.push(...parsed);
            }
            catch (e) {
                console.error("[Storage] ❌ Критическая ошибка парсинга JSON из PluginData:", e);
            }
        }
        if ('children' in node) {
            for (const child of node.children)
                collectErrorsRecursive(child);
        }
    }
    if (selection.length > 0) {
        selection.forEach(node => collectErrorsRecursive(node));
        const savedGroupState = selection[0].getPluginData('francoise_is_grouped');
        const isGrouped = savedGroupState === 'true';
        figma.ui.postMessage({
            type: 'selection-update',
            hasFrames: true,
            label: selection.length === 1 ? selection[0].name : `${selection.length} items`,
            savedErrors: loadedErrors,
            selectedIds: rawSelectedIds,
            rootSelectedIds: rootSelectedIds, // <--- ОТПРАВЛЯЕМ КОРНИ В UI
            isGrouped: isGrouped
        });
    }
    else {
        figma.ui.postMessage({
            type: 'selection-update',
            hasFrames: false,
            label: 'No selection',
            savedErrors: [],
            selectedIds: [],
            rootSelectedIds: [], // <--- ПУСТОЙ МАССИВ
            isGrouped: false
        });
    }
}
function findNodeByRelativePath(rootNode, path) {
    if (path === "root")
        return rootNode;
    const parts = path.split(" > ");
    let current = rootNode;
    for (let i = 1; i < parts.length; i++) {
        if (!current || !current.children)
            return null;
        const part = parts[i];
        const match = part.match(/(.+)\[(\d+)\]/);
        if (!match)
            return null;
        const name = match[1];
        const index = parseInt(match[2], 10);
        const siblings = current.children.filter((c) => name === "{*}" || c.name === name);
        current = siblings[index];
    }
    return current;
}
// --- 1. Вспомогательные функции для Preview ---
// Обнаружение столкновений (Collision Detection)
// --- 1. Вспомогательные функции для Preview ---
// Обнаружение столкновений (Collision Detection)
// Улучшенный алгоритм: игнорирует фреймы-контейнеры (подложки),
// проверяя коллизии только с соседями на всех уровнях вложенности.
// Обнаружение столкновений (Collision Detection)
// Улучшенный алгоритм: проверяет ТОЛЬКО место СПРАВА с большим отступом (чтобы обойти аннотации)
function getFreeSpaceForNode(targetNode) {
    console.log(`\n======================================================`);
    console.log(`👀 [Preview Debug] Проверка места для узла: "${targetNode.name}" (${targetNode.id})`);
    if (!('absoluteBoundingBox' in targetNode) || !targetNode.absoluteBoundingBox) {
        console.warn(`[Preview Debug] ❌ Ошибка: У узла нет absoluteBoundingBox. Отмена.`);
        return { hasSpace: false, x: 0, y: 0 };
    }
    const targetBounds = targetNode.absoluteBoundingBox;
    // 💡 Увеличиваем отступ со 100 до 400 пикселей, чтобы перепрыгнуть визуальный мусор от аннотаций
    const gap = 400;
    // 💡 Оставляем ТОЛЬКО кандидата справа
    const candidateRight = {
        x: targetBounds.x + targetBounds.width + gap,
        y: targetBounds.y,
        w: targetBounds.width,
        h: targetBounds.height
    };
    console.log(`[Preview Debug] Координаты оригинала: x=${targetBounds.x}, y=${targetBounds.y}, w=${targetBounds.width}, h=${targetBounds.height}`);
    const isCollision = (rect1, rect2) => {
        return rect1.x < rect2.x + rect2.w && rect1.x + rect1.w > rect2.x &&
            rect1.y < rect2.y + rect2.h && rect1.y + rect1.h > rect2.y;
    };
    const obstacles = [];
    let current = targetNode;
    while (current && current.parent && current.parent.type !== 'DOCUMENT') {
        for (const child of current.parent.children) {
            if (child.id !== current.id && 'visible' in child && child.visible) {
                obstacles.push(child);
            }
        }
        current = current.parent;
    }
    console.log(`[Preview Debug] Найдено ${obstacles.length} соседних узлов для проверки коллизий.`);
    let rightFree = true;
    for (const node of obstacles) {
        if (!('absoluteBoundingBox' in node) || !node.absoluteBoundingBox)
            continue;
        const b = node.absoluteBoundingBox;
        const nodeRect = { x: b.x, y: b.y, w: b.width, h: b.height };
        if (isCollision(candidateRight, nodeRect)) {
            console.log(`[Preview Debug] ⛔ Коллизия СПРАВА с узлом: "${node.name}" (${node.id})`);
            rightFree = false;
            break; // 💡 Так как кандидат всего один, при первой же коллизии можно выходить из цикла
        }
    }
    if (rightFree) {
        console.log(`[Preview Debug] ✅ Найдено свободное место СПРАВА (отступ ${gap}px).`);
        return { hasSpace: true, x: candidateRight.x, y: candidateRight.y };
    }
    console.log(`[Preview Debug] ❌ Свободного места справа нет. Нижний вариант отключен из-за аннотаций.`);
    return { hasSpace: false, x: 0, y: 0 };
}
// Рекурсивный маппинг ID: Оригинал -> Клон
function buildCloneMap(original, clone, map) {
    map.set(original.id, clone.id);
    if ('children' in original && 'children' in clone) {
        for (let i = 0; i < original.children.length; i++) {
            buildCloneMap(original.children[i], clone.children[i], map);
        }
    }
}
// Глубокое копирование ошибок с подменой ID
// Глубокое копирование ошибок с подменой ID
// Глубокое копирование с тотальной заменой ID во всех строковых полях (пуленепробиваемый метод)
function mapErrorsToClone(errors, idMap) {
    const replacer = (obj) => {
        if (typeof obj === 'string') {
            return idMap.has(obj) ? idMap.get(obj) : obj;
        }
        else if (Array.isArray(obj)) {
            return obj.map(item => replacer(item));
        }
        else if (obj !== null && typeof obj === 'object') {
            const newObj = {};
            for (const [key, value] of Object.entries(obj)) {
                newObj[key] = replacer(value);
            }
            return newObj;
        }
        return obj;
    };
    return replacer(errors);
}
// Тотальная очистка узла и его детей от аннотаций и PluginData
function clearAnnotationsRecursive(node) {
    if ('annotations' in node && node.annotations.length > 0) {
        node.annotations = [];
    }
    if ('setPluginData' in node) {
        node.setPluginData('francoise_errors', '');
        node.setPluginData('francoise_is_grouped', ''); // <--- ДОБАВИЛИ ОЧИСТКУ СТЕЙТА ГРУППИРОВКИ
        const chunksCountStr = node.getPluginData('francoise_errors_chunks');
        if (chunksCountStr) {
            const totalChunks = parseInt(chunksCountStr, 10);
            for (let i = 0; i < totalChunks; i++)
                node.setPluginData(`francoise_errors_${i}`, '');
            node.setPluginData('francoise_errors_chunks', '');
        }
    }
    if ('children' in node) {
        for (const child of node.children) {
            clearAnnotationsRecursive(child);
        }
    }
}
// Безопасная загрузка шрифтов: обрабатывает узлы со смешанными стилями (figma.mixed)
async function safelyLoadTextNodeFonts(node) {
    if (node.fontName === figma.mixed) {
        const len = node.characters.length;
        if (len === 0)
            return;
        const fontsToLoad = new Map();
        for (let i = 0; i < len; i++) {
            try {
                const font = node.getRangeFontName(i, i + 1);
                const fontKey = `${font.family}-${font.style}`;
                if (!fontsToLoad.has(fontKey))
                    fontsToLoad.set(fontKey, font);
            }
            catch (e) { }
        }
        await Promise.all(Array.from(fontsToLoad.values()).map(f => figma.loadFontAsync(f).catch(() => { })));
    }
    else {
        try {
            await figma.loadFontAsync(node.fontName);
        }
        catch (e) { }
    }
}
figma.on('selectionchange', notifySelectionUpdate);
notifySelectionUpdate();
checkEnvironment();
setInterval(checkEnvironment, 1000);
